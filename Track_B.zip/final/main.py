"""CLI entry point.

    python main.py --name "Mark Chahwan" --linkedin "https://www.linkedin.com/in/..."
    python main.py --name "Some Other Founder" --passes 2 --max-claims 8
"""

import argparse
import sys

import config
import pipeline


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Reputation Diagnostic Engine — generic public-figure fact diagnostic."
    )
    parser.add_argument("--name", required=True, help="Subject name.")
    parser.add_argument("--linkedin", default=None, help="Subject LinkedIn URL (optional).")
    parser.add_argument(
        "--passes", type=int, default=None, help="Verification passes per claim (2 or 3)."
    )
    parser.add_argument("--max-claims", type=int, default=None, help="Max claims to assess.")
    parser.add_argument("--quiet", action="store_true", help="Reduce console output.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if args.passes is not None:
        config.VERIFY_PASSES = max(2, min(3, args.passes))
    if args.max_claims is not None:
        config.MAX_CLAIMS = max(1, args.max_claims)

    try:
        config.require_api_key()
    except RuntimeError as e:
        print(f"Configuration error: {e}", file=sys.stderr)
        return 2

    try:
        run_dir = pipeline.run(args.name, args.linkedin, verbose=not args.quiet)
    except pipeline.PipelineError as e:
        print(f"\nRun failed at {e.stage}: {e.original}", file=sys.stderr)
        print("Partial state and full logs were saved. See run.log.", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        return 130

    print(f"Artefacts: {run_dir.resolve()}")
    print("  diagnostic_report.txt / .docx   — the one-page deliverable")
    print("  pipeline_data.json              — full structured run state")
    print("  events.jsonl / run.log          — structured + human logs")
    print("  raw/                            — per-stage checkpoints")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())