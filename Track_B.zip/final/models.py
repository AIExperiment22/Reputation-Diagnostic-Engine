"""Typed run objects. Everything persisted is built from these, so the JSON on
disk and the report always describe the same state."""

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class SubjectProfile:
    name: str
    linkedin_url: Optional[str] = None
    country: str = "unknown"
    jurisdiction: str = "unknown"
    industry: str = "unknown"
    company: str = "unknown"
    regulators: List[str] = field(default_factory=list)
    likely_languages: List[str] = field(default_factory=list)
    profiling_notes: str = ""
    profiling_confidence: str = "low"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Source:
    name: str = "unknown"
    url: str = ""
    date: str = "unknown"
    language: str = "unknown"
    source_type: str = "unknown"   # regulator|government|court|press|company|social|unknown
    tier: int = 4
    supports_claim: bool = False
    access: str = "public"         # public|gated|inaccessible
    note: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Claim:
    claim: str
    category: str = "other"
    self_reported: bool = False
    source_language: str = "unknown"
    contains_superlative: bool = False
    superlative_terms: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class VerificationPass:
    pass_number: int
    model_status: str = "UNVERIFIED"
    conflict: str = "none"          # none|minor|core
    reasoning: str = ""
    sources: List[Source] = field(default_factory=list)
    error: Optional[str] = None
    retrieved_urls: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["sources"] = [s.to_dict() for s in self.sources]
        return d


@dataclass
class VerifiedClaim:
    claim: Claim
    status: str = "UNVERIFIED"
    reasoning: str = ""
    passes: List[VerificationPass] = field(default_factory=list)
    sources: List[Source] = field(default_factory=list)
    independent_source_count: int = 0
    best_tier: int = 4
    conflict: str = "none"
    bilingual_review_required: bool = False
    rule_notes: List[str] = field(default_factory=list)
    system_error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "claim": self.claim.to_dict(),
            "status": self.status,
            "reasoning": self.reasoning,
            "passes": [p.to_dict() for p in self.passes],
            "sources": [s.to_dict() for s in self.sources],
            "independent_source_count": self.independent_source_count,
            "best_tier": self.best_tier,
            "conflict": self.conflict,
            "bilingual_review_required": self.bilingual_review_required,
            "rule_notes": self.rule_notes,
            "system_error": self.system_error,
        }


@dataclass
class Gap:
    title: str
    explanation: str
    basis: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RunResult:
    run_id: str
    started_at: str
    finished_at: str = ""
    profile: Optional[SubjectProfile] = None
    research_text: str = ""
    research_sources: List[Source] = field(default_factory=list)
    inaccessible_sources: List[Source] = field(default_factory=list)
    claims: List[Claim] = field(default_factory=list)
    verified: List[VerifiedClaim] = field(default_factory=list)
    gaps: List[Gap] = field(default_factory=list)
    refused: Optional[VerifiedClaim] = None
    refusal_reason: str = ""
    stage_errors: List[Dict[str, Any]] = field(default_factory=list)
    limitations: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "profile": self.profile.to_dict() if self.profile else None,
            "research_text": self.research_text,
            "research_sources": [s.to_dict() for s in self.research_sources],
            "inaccessible_sources": [s.to_dict() for s in self.inaccessible_sources],
            "claims": [c.to_dict() for c in self.claims],
            "verified": [v.to_dict() for v in self.verified],
            "gaps": [g.to_dict() for g in self.gaps],
            "refused": self.refused.to_dict() if self.refused else None,
            "refusal_reason": self.refusal_reason,
            "stage_errors": self.stage_errors,
            "limitations": self.limitations,
        }