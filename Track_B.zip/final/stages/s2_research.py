"""Stage 2 — Research / data collection.

Multi-query public research, jurisdiction-aware. Source language is recorded,
never discarded. Gated sources are recorded as inaccessible for this run rather
than silently dropped.
"""

import logging
from typing import List, Tuple

import config
import logging_setup
from llm_client import call_llm_json
from models import Source, SubjectProfile
from rules import normalize_sources

log = logging.getLogger("repdiag")
STAGE = "stage2_research"

PROMPT_OLD = """Research this subject using live web search across MULTIPLE targeted queries.

Subject: {name}
Company: {company}
Industry: {industry}
Jurisdiction: {jurisdiction}
Relevant regulators/registries for this jurisdiction: {regulators}
Local press is likely to publish in: {languages}

Run separate targeted searches for each of:
1. Career background and education
2. Company founded — name, year, what it does
3. Funding history — rounds, amounts, investors, dates
4. Major milestones and recent achievements
5. Press coverage and awards
6. Regulatory record, licences, enforcement actions, fines, litigation or
   controversies. Search for this specifically and directly. Do not report
   "none found" unless you actually ran targeted searches for it — say which
   searches you ran.

Rules:
- Include a source if it is freely and publicly accessible without login or
  payment, regardless of source type or LANGUAGE. Search in {languages} as well
  as English where that is likely to surface local coverage.
- Exclude a source ONLY if access is actually gated. List those separately under
  "inaccessible" with the reason.
- Record each source's language. Do not drop non-English sources.
- Mark each fact as self-reported (company site, LinkedIn, press release) or
  independently reported (press, regulator, court).
- If you cannot confirm something, say so explicitly rather than inferring.

Return JSON:
{{"findings": "<detailed prose write-up of everything found, with outlet name and
date beside each fact, and self-reported vs independently-reported marked>",
  "searches_run": ["<query 1>", "<query 2>"],
  "sources": [{{"name": "", "url": "", "date": "", "language": "en",
               "source_type": "regulator|government|court|press|company|social",
               "access": "public", "note": ""}}],
  "inaccessible": [{{"name": "", "url": "", "access": "gated",
                    "note": "<why it could not be read>"}}],
  "regulatory_searches_run": ["<the specific queries used for item 6>"],
  "regulatory_findings": "<what those searches returned, including a genuine
   'nothing found' statement if that is the honest result>"}}
"""

PROMPT = """Research this subject using live web search across MULTIPLE targeted queries.

Subject: {name}
Company: {company}
Industry: {industry}
Jurisdiction: {jurisdiction}
Relevant regulators/registries for this jurisdiction: {regulators}
Local press is likely to publish in: {languages}

Run separate targeted searches for each of:
1. Career background and education
2. Company founded — name, year, what it does
3. Funding history — rounds, amounts, investors, dates
4. Major milestones and recent achievements — excluding scale metrics, which
   are covered separately in item 7 below
5. Press coverage and awards
6. Regulatory record, licences, enforcement actions, fines, litigation or
   controversies. Search for this specifically and directly. Do not report
   "none found" unless you actually ran targeted searches for it — say which
   searches you ran.
7. Scale metrics — assets under management (AUM), total registered users,
   revenue, valuation, or any "first company to..." / "largest in region"
   type claim. These are often the single most important public facts about
   a company and must not be left to a general achievements search. Run at
   least two searches for this specifically:
     - "[company] assets under management" OR "[company] AUM"
     - "[company] users milestone" OR "[company] registered users"
   If different searches return the same metric at different values with
   different dates (e.g. AUM at one figure in an earlier year, a higher
   figure more recently), report ALL of them with their dates. That is
   growth over time, not a conflict, and every dated figure matters.

Rules:
- Include a source if it is freely and publicly accessible without login or
  payment, regardless of source type or LANGUAGE. Search in {languages} as well
  as English where that is likely to surface local coverage.
- Exclude a source ONLY if access is actually gated. List those separately under
  "inaccessible" with the reason.
- Record each source's language. Do not drop non-English sources.
- Mark each fact as self-reported (company site, LinkedIn, press release) or
  independently reported (press, regulator, court).
- If you cannot confirm something, say so explicitly rather than inferring.

Return JSON:
{{"findings": "<detailed prose write-up of everything found, with outlet name and
date beside each fact, and self-reported vs independently-reported marked>",
  "searches_run": ["<query 1>", "<query 2>"],
  "sources": [{{"name": "", "url": "", "date": "", "language": "en",
               "source_type": "regulator|government|court|press|company|social",
               "access": "public", "note": ""}}],
  "inaccessible": [{{"name": "", "url": "", "access": "gated",
                    "note": "<why it could not be read>"}}],
  "regulatory_searches_run": ["<the specific queries used for item 6>"],
  "regulatory_findings": "<what those searches returned, including a genuine
   'nothing found' statement if that is the honest result>",
  "scale_searches_run": ["<the specific queries used for item 7>"],
  "scale_findings": "<every scale/AUM/user-count figure found, each with its
   own date and source, including a genuine 'nothing found' statement if
   that is the honest result>"}}
"""

def run(profile: SubjectProfile) -> Tuple[str, List[Source], List[Source], dict]:
    log.info("Researching %s", profile.name, extra={"stage": STAGE})
    logging_setup.event(STAGE, "start", subject=profile.name)

    data, urls = call_llm_json(
        PROMPT.format(
            name=profile.name,
            company=profile.company,
            industry=profile.industry,
            jurisdiction=profile.jurisdiction,
            regulators=", ".join(profile.regulators) or "unknown",
            languages=", ".join(profile.likely_languages) or "en",
        ),
        search=True,
        max_searches=config.MAX_SEARCHES_RESEARCH,
        stage=STAGE,
    )
    if not isinstance(data, dict):
        raise RuntimeError("Stage 2 expected a JSON object.")

    findings = str(data.get("findings") or "").strip()
    if not findings:
        raise RuntimeError("Stage 2 returned no findings text.")

    # regulatory = str(data.get("regulatory_findings") or "").strip()
    # if regulatory:
    #     findings += "\n\nREGULATORY / CONTROVERSY SEARCH RESULT:\n" + regulatory

    regulatory = str(data.get("regulatory_findings") or "").strip()
    if regulatory:
        findings += "\n\nREGULATORY / CONTROVERSY SEARCH RESULT:\n" + regulatory

    scale = str(data.get("scale_findings") or "").strip()
    if scale:
        findings += "\n\nSCALE / AUM SEARCH RESULT:\n" + scale

    sources = normalize_sources(data.get("sources"))
    inaccessible = normalize_sources(data.get("inaccessible"))
    for s in inaccessible:
        if s.access == "public":
            s.access = "gated"

    # meta = {
    #     "searches_run": data.get("searches_run") or [],
    #     "regulatory_searches_run": data.get("regulatory_searches_run") or [],
    #     "retrieved_urls": urls,
    # }

    meta = {
        "searches_run": data.get("searches_run") or [],
        "regulatory_searches_run": data.get("regulatory_searches_run") or [],
        "scale_searches_run": data.get("scale_searches_run") or [],
        "retrieved_urls": urls,
    }

    log.info(
        "Collected %d public sources, %d inaccessible, %d searches run.",
        len(sources), len(inaccessible), len(meta["searches_run"]),
        extra={"stage": STAGE},
    )
    logging_setup.event(
        STAGE, "done",
        sources=len(sources), inaccessible=len(inaccessible), meta=meta,
    )
    return findings, sources, inaccessible, meta