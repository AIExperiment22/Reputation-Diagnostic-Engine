"""Stage 6 — Output generation.

Fixed one-page structure: fact table, three gaps, one explicitly refused claim,
reviewer sign-off field, run-specific limitations. Every claim carries a named,
dated source — no source, no claim.
"""

import logging
from pathlib import Path
from typing import List
import house_style

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor, Inches

import config
import logging_setup
from models import RunResult, Source, VerifiedClaim

log = logging.getLogger("repdiag")
STAGE = "stage6_report"

_RULE = "=" * 78

MAX_CLAIMS_ON_PAGE = 3
REASONING_CHARS = 80


def build_limitations(result: RunResult) -> dict:
    non_english = sorted(
        {
            s.language
            for v in result.verified
            for s in s_list(v)
            if s.language not in ("en", "english", "unknown", "")
        }
    )
    return {
        "verification_depth": f"{config.VERIFY_PASSES} independent search passes per claim",
        "claims_assessed": len(result.verified),
        "verified_count": sum(1 for v in result.verified if v.status == config.STATUS_VERIFIED),
        "partial_count": sum(1 for v in result.verified if v.status == config.STATUS_PARTIAL),
        "unverified_count": sum(1 for v in result.verified if v.status == config.STATUS_UNVERIFIED),
        "public_sources_checked": len(result.research_sources),
        "inaccessible_sources": [
            {"name": s.name, "url": s.url, "reason": s.note or s.access}
            for s in result.inaccessible_sources
        ],
        "claims_resting_on_non_english_sources": sum(
            1 for v in result.verified if v.bilingual_review_required
        ),
        "non_english_languages_used": non_english,
        "claims_with_system_errors": sum(1 for v in result.verified if v.system_error),
        "jurisdiction_checked": result.profile.jurisdiction if result.profile else "unknown",
        "regulators_considered": result.profile.regulators if result.profile else [],
    }


def s_list(v: VerifiedClaim) -> List[Source]:
    return v.sources or []


def _source_line(v: VerifiedClaim) -> str:
    supporting = [s for s in v.sources if s.supports_claim]
    if not supporting:
        return "No supporting public source found — claim not publishable."
    return " | ".join(
        f"{s.name} ({s.date}, {s.language}, tier {s.tier})"
        + (f" {s.url}" if s.url else "")
        for s in supporting[:4]
    )


def build_text(result: RunResult) -> str:
    profile = result.profile
    lim = result.limitations
    lines: List[str] = []

    lines.append("REPUTATION DIAGNOSTIC")
    lines.append(_RULE)
    lines.append(f"Subject       : {profile.name if profile else 'unknown'}")
    lines.append(f"Company       : {profile.company if profile else 'unknown'}")
    lines.append(
        f"Jurisdiction  : {profile.jurisdiction if profile else 'unknown'} "
        f"({profile.country if profile else 'unknown'})"
    )
    lines.append(f"Run ID        : {result.run_id}")
    lines.append(f"Generated     : {result.finished_at}")
    lines.append("Reviewed by   : ______________________  Date: __________")
    lines.append(
        "                [MANDATORY — not client-ready until a named reviewer signs off]"
    )
    lines.append("")

    lines.append("1. FACT VERIFICATION")
    lines.append("-" * 78)
    for v in result.verified:
        flag = "  [BILINGUAL REVIEW REQUIRED]" if v.bilingual_review_required else ""
        star = "  [SUPERLATIVE]" if v.claim.contains_superlative else ""
        lines.append(f"[{v.status}]{star}{flag}")
        lines.append(f"  Claim   : {v.claim.claim}")
        lines.append(f"  Basis   : {v.reasoning or 'No supporting reasoning recorded.'}")
        lines.append(f"  Sources : {_source_line(v)}")
        if v.rule_notes:
            lines.append(f"  Rules   : {' '.join(v.rule_notes)}")
        if v.system_error:
            lines.append(f"  System  : {v.system_error}")
        lines.append("")

    lines.append("2. GAPS IN PUBLIC PRESENCE")
    lines.append("-" * 78)
    for i, gap in enumerate(result.gaps, start=1):
        lines.append(f"  {i}. {gap.title}")
        lines.append(f"     {gap.explanation}")
        if gap.basis:
            lines.append(f"     Basis: {gap.basis}")
    lines.append("")

    # lines.append("3. CLAIM REFUSED (MANDATORY EXCLUSION)")
    # lines.append("-" * 78)
    # if result.refused:
    #     lines.append(f"  Claim : {result.refused.claim.claim}")
    #     lines.append(f"  Status: {result.refused.status}")
    # else:
    #     lines.append("  Claim : (none — no claims were extracted this run)")
    # lines.append(f"  Reason: {result.refusal_reason}")
    # lines.append("")

    lines.append("3. CLAIM REFUSED (MANDATORY EXCLUSION)")
    lines.append("-" * 78)
    if result.refused:
        lines.append(f"  Claim : {result.refused.claim.claim}")
        lines.append(f"  Status: {result.refused.status}")
    else:
        lines.append("  Claim : (none — no claims were extracted this run)")

    refusal_reason = (result.refusal_reason or "").strip()
    if len(refusal_reason) > 220:
        refusal_reason = refusal_reason[:217].rsplit(" ", 1)[0] + "..."

    lines.append(f"  Reason: {refusal_reason}")
    lines.append("")

    lines.append("4. RESEARCH LIMITATIONS (THIS RUN)")
    lines.append("-" * 78)
    lines.append(f"  Verification depth      : {lim['verification_depth']}")
    lines.append(
        f"  Claims assessed         : {lim['claims_assessed']} "
        f"({lim['verified_count']} verified / {lim['partial_count']} partial / "
        f"{lim['unverified_count']} unverified)"
    )
    lines.append(f"  Public sources checked  : {lim['public_sources_checked']}")
    lines.append(f"  Jurisdiction checked    : {lim['jurisdiction_checked']}")
    lines.append(
        f"  Regulators considered   : {', '.join(lim['regulators_considered']) or 'none identified'}"
    )
    lines.append(
        f"  Non-English evidence    : {lim['claims_resting_on_non_english_sources']} claim(s) "
        f"rest on non-English sources"
        + (f" ({', '.join(lim['non_english_languages_used'])})"
           if lim["non_english_languages_used"] else "")
    )
    if lim["inaccessible_sources"]:
        lines.append("  Inaccessible sources    :")
        for item in lim["inaccessible_sources"]:
            lines.append(f"      - {item['name']}: {item['reason']}")
    else:
        lines.append("  Inaccessible sources    : none encountered")
    if lim["claims_with_system_errors"]:
        lines.append(
            f"  Technical failures      : {lim['claims_with_system_errors']} claim(s) had at "
            "least one failed verification pass — see run.log"
        )
    lines.append("")
    lines.append(
        "  This system assists a human reviewer; it does not replace one. No output is "
        "client-ready without sign-off above."
    )
    lines.append(_RULE)
    return "\n".join(lines)


def build_docx(result: RunResult, path: Path) -> Path:
    doc = Document()

    # Only changed: tighter margins for one-page output.
    for section in doc.sections:
        section.top_margin = Inches(0.35)
        section.bottom_margin = Inches(0.35)
        section.left_margin = Inches(0.35)
        section.right_margin = Inches(0.35)

    style = doc.styles["Normal"]
    style.font.name = "Calibri"

    # Only changed: minimum content font size = 10 pt.
    style.font.size = Pt(10)

    heading = doc.add_paragraph()
    heading.paragraph_format.space_after = Pt(1)
    run_ = heading.add_run("REPUTATION DIAGNOSTIC")
    run_.bold = True
    run_.font.size = Pt(16)
    heading.alignment = WD_ALIGN_PARAGRAPH.LEFT

    profile = result.profile
    meta = doc.add_paragraph()
    meta.paragraph_format.space_after = Pt(1)
    meta.add_run(
        f"Subject: {profile.name if profile else 'unknown'}    "
        f"Company: {profile.company if profile else 'unknown'}    "
        f"Jurisdiction: {profile.jurisdiction if profile else 'unknown'}\n"
        f"Run ID: {result.run_id}    Generated: {result.finished_at}"
    )
    for r in meta.runs:
        r.font.size = Pt(10)

    sign = doc.add_paragraph()
    sign.paragraph_format.space_after = Pt(2)
    sign_run = sign.add_run(
        "Reviewed by: ______________________   Date: __________   "
        "(mandatory — not client-ready without sign-off)"
    )
    sign_run.bold = True
    sign_run.font.size = Pt(10)
    sign_run.font.color.rgb = RGBColor(0xB0, 0x00, 0x00)

    fact_heading = doc.add_paragraph()
    fact_heading.paragraph_format.space_before = Pt(1)
    fact_heading.paragraph_format.space_after = Pt(1)
    fact_heading.add_run("1. FACT VERIFICATION").bold = True

    table = doc.add_table(rows=1, cols=4)
    table.style = "Table Grid"

    for i, header in enumerate(["Status", "Claim", "Basis", "Source (name, date, lang, tier)"]):
        cell = table.rows[0].cells[i]
        cell.text = header
        cell.paragraphs[0].paragraph_format.space_before = Pt(0)
        cell.paragraphs[0].paragraph_format.space_after = Pt(0)
        cell.paragraphs[0].runs[0].bold = True
        cell.paragraphs[0].runs[0].font.size = Pt(10)

    # Only changed: show maximum 3 claims to keep the diagnostic one page.
    shown = result.verified[:MAX_CLAIMS_ON_PAGE]
    held_back_count = max(0, len(result.verified) - len(shown))

    for v in shown:
        row = table.add_row().cells

        status = v.status
        if v.bilingual_review_required:
            status += "\n[BILINGUAL REVIEW]"
        if v.claim.contains_superlative:
            status += "\n[SUPERLATIVE]"

        row[0].text = status
        row[1].text = v.claim.claim

        # Only changed: reduce displayed reasoning to fit one page.
        row[2].text = house_style.apply(
            v.reasoning or "none recorded"
        )[:REASONING_CHARS]

        row[3].text = _source_line(v)

        for cell in row:
            for para in cell.paragraphs:
                para.paragraph_format.space_before = Pt(0)
                para.paragraph_format.space_after = Pt(0)
                for run in para.runs:
                    run.font.size = Pt(10)

    if held_back_count:
        note = doc.add_paragraph()
        note.paragraph_format.space_before = Pt(1)
        note.paragraph_format.space_after = Pt(0)
        note_run = note.add_run(
            f"+ {held_back_count} additional claim(s) assessed. Full detail: "
            "reviewer console / pipeline_data.json."
        )
        note_run.font.size = Pt(10)

    gaps_heading = doc.add_paragraph()
    gaps_heading.paragraph_format.space_before = Pt(2)
    gaps_heading.paragraph_format.space_after = Pt(1)
    gaps_heading.add_run("2. GAPS IN PUBLIC PRESENCE").bold = True

    for i, gap in enumerate(result.gaps, start=1):
        para = doc.add_paragraph()
        para.paragraph_format.space_before = Pt(0)
        para.paragraph_format.space_after = Pt(0)

        r1 = para.add_run(f"{i}. {gap.title} — ")
        r1.bold = True
        r1.font.size = Pt(10)

        r2 = para.add_run(
            house_style.apply(
                gap.explanation + (f" (Basis: {gap.basis})" if gap.basis else "")
            )
        )
        r2.font.size = Pt(10)

    refused_heading = doc.add_paragraph()
    refused_heading.paragraph_format.space_before = Pt(2)
    refused_heading.paragraph_format.space_after = Pt(1)
    refused_heading.add_run("3. CLAIM REFUSED (MANDATORY EXCLUSION)").bold = True

    refused_para = doc.add_paragraph()
    refused_para.paragraph_format.space_before = Pt(0)
    refused_para.paragraph_format.space_after = Pt(0)

    if result.refused:
        r = refused_para.add_run("Claim: ")
        r.bold = True
        r.font.size = Pt(10)

        r = refused_para.add_run(
            result.refused.claim.claim + f"  [{result.refused.status}]\n"
        )
        r.font.size = Pt(10)

    r = refused_para.add_run("Reason: ")
    r.bold = True
    r.font.size = Pt(10)

    r = refused_para.add_run(result.refusal_reason)
    r.font.size = Pt(10)

    limitations_heading = doc.add_paragraph()
    limitations_heading.paragraph_format.space_before = Pt(2)
    limitations_heading.paragraph_format.space_after = Pt(1)
    limitations_heading.add_run("4. RESEARCH LIMITATIONS (THIS RUN)").bold = True

    lim = result.limitations
    limit_para = doc.add_paragraph()
    limit_para.paragraph_format.space_before = Pt(0)
    limit_para.paragraph_format.space_after = Pt(0)

    r = limit_para.add_run(
        f"Verification depth: {lim['verification_depth']}. "
        f"Claims assessed: {lim['claims_assessed']} "
        f"({lim['verified_count']} verified / {lim['partial_count']} partial / "
        f"{lim['unverified_count']} unverified). "
        f"Public sources checked: {lim['public_sources_checked']}. "
        f"Jurisdiction: {lim['jurisdiction_checked']}. "
        f"Claims resting on non-English sources: "
        f"{lim['claims_resting_on_non_english_sources']}. "
        f"Inaccessible sources: "
        + (
            "; ".join(f"{i['name']} ({i['reason']})" for i in lim["inaccessible_sources"])
            or "none encountered"
        )
        + ". This system assists a human reviewer; it does not replace one."
    )
    r.font.size = Pt(10)

    doc.save(path)
    return path


def run(result: RunResult, run_dir: Path) -> str:
    log.info("Generating report", extra={"stage": STAGE})
    result.limitations = build_limitations(result)

    # text = build_text(result)
    # (run_dir / "diagnostic_report.txt").write_text(text, encoding="utf-8")

    text = house_style.apply(build_text(result))
    remaining = house_style.check(text)
    if remaining:
        log.warning("House-style issues remain: %s", "; ".join(remaining),
                    extra={"stage": STAGE})
        logging_setup.event(STAGE, "house_style_warning", problems=remaining)
    (run_dir / "diagnostic_report.txt").write_text(text, encoding="utf-8")

    try:
        build_docx(result, run_dir / "diagnostic_report.docx")
        docx_ok = True
    except Exception as e:
        docx_ok = False
        log.error("DOCX generation failed: %s (text report still written)", e,
                  extra={"stage": STAGE})
        logging_setup.event(STAGE, "docx_failed", error=str(e))

    logging_setup.event(STAGE, "done", docx=docx_ok)
    return text