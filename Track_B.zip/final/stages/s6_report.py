"""Stage 6 — Output generation.

Fixed one-page structure: fact table, three gaps, one explicitly refused claim,
reviewer sign-off field, run-specific limitations. Every claim carries a named,
dated source — no source, no claim.
"""

import logging
from pathlib import Path
from typing import List
import house_style

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor, Inches

import config
import logging_setup
from llm_client import call_llm_json
from models import RunResult, Source, VerifiedClaim

log = logging.getLogger("repdiag")
STAGE = "stage6_report"

_RULE = "=" * 78

MAX_CLAIMS_ON_PAGE = 3
REASONING_CHARS = 80


def build_limitations(result: RunResult) -> dict:
    non_english = sorted(
        {
            s.language
            for v in result.verified
            for s in s_list(v)
            if s.language not in ("en", "english", "unknown", "")
        }
    )
    return {
        "verification_depth": f"{config.VERIFY_PASSES} independent search passes per claim",
        "claims_assessed": len(result.verified),
        "verified_count": sum(1 for v in result.verified if v.status == config.STATUS_VERIFIED),
        "partial_count": sum(1 for v in result.verified if v.status == config.STATUS_PARTIAL),
        "unverified_count": sum(1 for v in result.verified if v.status == config.STATUS_UNVERIFIED),
        "public_sources_checked": len(result.research_sources),
        "inaccessible_sources": [
            {"name": s.name, "url": s.url, "reason": s.note or s.access}
            for s in result.inaccessible_sources
        ],
        "claims_resting_on_non_english_sources": sum(
            1 for v in result.verified if v.bilingual_review_required
        ),
        "non_english_languages_used": non_english,
        "claims_with_system_errors": sum(1 for v in result.verified if v.system_error),
        "jurisdiction_checked": result.profile.jurisdiction if result.profile else "unknown",
        "regulators_considered": result.profile.regulators if result.profile else [],
    }


def s_list(v: VerifiedClaim) -> List[Source]:
    return v.sources or []


def _source_line(v: VerifiedClaim) -> str:
    supporting = [s for s in v.sources if s.supports_claim]
    if not supporting:
        return "No supporting public source found — claim not publishable."
    return " | ".join(
        f"{s.name} ({s.date}, {s.language}, tier {s.tier})"
        + (f" {s.url}" if s.url else "")
        for s in supporting[:4]
    )


def build_text(result: RunResult) -> str:
    profile = result.profile
    lim = result.limitations
    lines: List[str] = []

    lines.append("REPUTATION DIAGNOSTIC")
    lines.append(_RULE)
    lines.append(f"Subject       : {profile.name if profile else 'unknown'}")
    lines.append(f"Company       : {profile.company if profile else 'unknown'}")
    lines.append(
        f"Jurisdiction  : {profile.jurisdiction if profile else 'unknown'} "
        f"({profile.country if profile else 'unknown'})"
    )
    lines.append(f"Run ID        : {result.run_id}")
    lines.append(f"Generated     : {result.finished_at}")
    lines.append("Reviewed by   : ______________________  Date: __________")
    lines.append(
        "                [MANDATORY — not client-ready until a named reviewer signs off]"
    )
    lines.append("")

    lines.append("1. FACT VERIFICATION")
    lines.append("-" * 78)
    for v in result.verified:
        flag = "  [BILINGUAL REVIEW REQUIRED]" if v.bilingual_review_required else ""
        star = "  [SUPERLATIVE]" if v.claim.contains_superlative else ""
        lines.append(f"[{v.status}]{star}{flag}")
        lines.append(f"  Claim   : {v.claim.claim}")
        lines.append(f"  Basis   : {v.reasoning or 'No supporting reasoning recorded.'}")
        lines.append(f"  Sources : {_source_line(v)}")
        if v.rule_notes:
            lines.append(f"  Rules   : {' '.join(v.rule_notes)}")
        if v.system_error:
            lines.append(f"  System  : {v.system_error}")
        lines.append("")

    lines.append("2. GAPS IN PUBLIC PRESENCE")
    lines.append("-" * 78)
    for i, gap in enumerate(result.gaps, start=1):
        lines.append(f"  {i}. {gap.title}")
        lines.append(f"     {gap.explanation}")
        if gap.basis:
            lines.append(f"     Basis: {gap.basis}")
    lines.append("")

    lines.append("3. CLAIM REFUSED (MANDATORY EXCLUSION)")
    lines.append("-" * 78)
    if result.refused:
        lines.append(f"  Claim : {result.refused.claim.claim}")
        lines.append(f"  Status: {result.refused.status}")
    else:
        lines.append("  Claim : (none — no claims were extracted this run)")
    lines.append(f"  Reason: {result.refusal_reason}")
    lines.append("")

    lines.append("4. RESEARCH LIMITATIONS (THIS RUN)")
    lines.append("-" * 78)
    lines.append(f"  Verification depth      : {lim['verification_depth']}")
    lines.append(
        f"  Claims assessed         : {lim['claims_assessed']} "
        f"({lim['verified_count']} verified / {lim['partial_count']} partial / "
        f"{lim['unverified_count']} unverified)"
    )
    lines.append(f"  Public sources checked  : {lim['public_sources_checked']}")
    lines.append(f"  Jurisdiction checked    : {lim['jurisdiction_checked']}")
    lines.append(
        f"  Regulators considered   : {', '.join(lim['regulators_considered']) or 'none identified'}"
    )
    lines.append(
        f"  Non-English evidence    : {lim['claims_resting_on_non_english_sources']} claim(s) "
        f"rest on non-English sources"
        + (f" ({', '.join(lim['non_english_languages_used'])})"
           if lim["non_english_languages_used"] else "")
    )
    if lim["inaccessible_sources"]:
        lines.append("  Inaccessible sources    :")
        for item in lim["inaccessible_sources"]:
            lines.append(f"      - {item['name']}: {item['reason']}")
    else:
        lines.append("  Inaccessible sources    : none encountered")
    if lim["claims_with_system_errors"]:
        lines.append(
            f"  Technical failures      : {lim['claims_with_system_errors']} claim(s) had at "
            "least one failed verification pass — see run.log"
        )
    lines.append("")
    lines.append(
        "  This system assists a human reviewer; it does not replace one. No output is "
        "client-ready without sign-off above."
    )
    lines.append(_RULE)
    return "\n".join(lines)


def compress_for_one_page(result: RunResult, text: str) -> str:
    """Use the LLM only as a presentation compressor; facts and statuses are not changed."""
    prompt = """Compress the following Reputation Diagnostic into ONE PAGE of dense,
reviewer-readable text.

This is a formatting/compression task, NOT a research or verification task.

NON-NEGOTIABLE RULES:
- Preserve every claim's exact VERIFIED / PARTIALLY VERIFIED / UNVERIFIED status.
- Preserve every refused claim and its refusal reason.
- Preserve all 3 gaps, but compress each to one short sentence.
- Preserve subject, company, jurisdiction, run ID and reviewer sign-off line.
- Preserve material evidence, important source names, dates, tiers and URLs where present.
- Preserve research limitations and technical-failure information.
- Do NOT add facts, sources, interpretations, conclusions or recommendations.
- Do NOT change, merge, upgrade or downgrade any verification status.
- Remove repetition, verbose reasoning, duplicated source descriptions and filler.
- Use compact labels and semicolon-separated facts where possible.
- The output MUST be plain text only.
- Target no more than 5,500 characters.
- The output MUST retain these four sections:
  1. FACT VERIFICATION
  2. GAPS IN PUBLIC PRESENCE
  3. CLAIM REFUSED (MANDATORY EXCLUSION)
  4. RESEARCH LIMITATIONS (THIS RUN)

SOURCE REPORT:
{text}
"""

    try:
        data, _ = call_llm_json(
            prompt.format(text=text),
            search=False,
            stage=STAGE,
        )

        # Accept either {"text": "..."} or {"compressed_text": "..."}.
        if isinstance(data, dict):
            compressed = str(
                data.get("compressed_text")
                or data.get("text")
                or ""
            ).strip()
        elif isinstance(data, str):
            compressed = data.strip()
        else:
            compressed = ""

        if not compressed:
            raise RuntimeError("Stage 6 compression returned empty output.")

        # Hard safety guard: if the model ignores the requested budget, retry once
        # with a stronger compression instruction rather than writing a multi-page file.
        if len(compressed) > 5500:
            retry_prompt = """Compress this report again to MAXIMUM 5,000 characters.
Keep all four required sections, every claim status, the refused claim/reason,
all three gaps, key evidence/source names, and research limitations.
Do not add or change facts. Return JSON exactly as {"compressed_text": "<compressed report>"}.

REPORT:
{report}
"""
            retry_data, _ = call_llm_json(
                retry_prompt.format(report=compressed),
                search=False,
                stage=STAGE,
            )
            if isinstance(retry_data, dict):
                compressed = str(
                    retry_data.get("compressed_text")
                    or retry_data.get("text")
                    or ""
                ).strip()
            elif isinstance(retry_data, str):
                compressed = retry_data.strip()

        if not compressed:
            raise RuntimeError("Stage 6 second compression returned empty output.")

        if len(compressed) > 5500:
            raise RuntimeError(
                f"Compressed report is still too long ({len(compressed)} characters)."
            )

        return house_style.apply(compressed)

    except Exception as e:
        # Compression is presentation-only. Never destroy a valid diagnostic because
        # the presentation LLM failed.
        log.warning(
            "LLM one-page compression failed; using original report text: %s",
            e,
            extra={"stage": STAGE},
        )
        logging_setup.event(
            STAGE, "compression_failed", error=str(e)
        )
        return house_style.apply(text)


def build_docx(result: RunResult, path: Path, compressed_text: str) -> Path:
    """Render the already-compressed Stage 6 text as a single dense DOCX page."""
    doc = Document()

    for section in doc.sections:
        section.top_margin = Inches(0.25)
        section.bottom_margin = Inches(0.25)
        section.left_margin = Inches(0.30)
        section.right_margin = Inches(0.30)

    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(8.5)
    style.paragraph_format.space_before = Pt(0)
    style.paragraph_format.space_after = Pt(0)
    style.paragraph_format.line_spacing = 0.88

    # One compact text flow is intentional: the LLM has already compressed the
    # complete diagnostic, so a large table cannot expand it back into multiple pages.
    for index, line in enumerate(compressed_text.splitlines()):
        para = doc.add_paragraph()
        para.paragraph_format.space_before = Pt(0)
        para.paragraph_format.space_after = Pt(0)
        para.paragraph_format.line_spacing = 0.88

        run = para.add_run(line)
        run.font.name = "Calibri"
        run.font.size = Pt(8.5)

        if (
            line.startswith("REPUTATION DIAGNOSTIC")
            or line.startswith("1. FACT VERIFICATION")
            or line.startswith("2. GAPS IN PUBLIC PRESENCE")
            or line.startswith("3. CLAIM REFUSED")
            or line.startswith("4. RESEARCH LIMITATIONS")
        ):
            run.bold = True
            run.font.size = Pt(9.5)

    # Prevent an accidental blank trailing paragraph from consuming space.
    if doc.paragraphs:
        doc.paragraphs[-1].paragraph_format.space_after = Pt(0)

    doc.save(path)
    return path


def run(result: RunResult, run_dir: Path) -> str:
    log.info("Generating report", extra={"stage": STAGE})
    result.limitations = build_limitations(result)

    # text = build_text(result)
    # (run_dir / "diagnostic_report.txt").write_text(text, encoding="utf-8")

    original_text = house_style.apply(build_text(result))

    # Stage 6 presentation compression only. The underlying pipeline data and
    # verification statuses remain unchanged.
    text = compress_for_one_page(result, original_text)

    remaining = house_style.check(text)
    if remaining:
        log.warning("House-style issues remain: %s", "; ".join(remaining),
                    extra={"stage": STAGE})
        logging_setup.event(STAGE, "house_style_warning", problems=remaining)

    (run_dir / "diagnostic_report.txt").write_text(text, encoding="utf-8")
    (run_dir / "diagnostic_onepage.txt").write_text(text, encoding="utf-8")

    try:
        build_docx(result, run_dir / "diagnostic_report.docx", text)
        docx_ok = True
    except Exception as e:
        docx_ok = False
        log.error("DOCX generation failed: %s (text report still written)", e,
                  extra={"stage": STAGE})
        logging_setup.event(STAGE, "docx_failed", error=str(e))

    logging_setup.event(STAGE, "done", docx=docx_ok)
    return text