"""Stage 3 — Claim extraction.

Language-aware: claims are extracted in whatever language the source used.
Superlative detection is done in code afterwards so it cannot be skipped.
"""

import logging
from typing import List

import config
import logging_setup
from llm_client import call_llm_json
from models import Claim
from rules import detect_superlatives

log = logging.getLogger("repdiag")
STAGE = "stage3_extract"

PROMPT = """Extract every specific, checkable factual claim from this research.

A checkable claim contains a number, a date, a named entity or a named milestone
— something that could be confirmed or contradicted by an independent source.
Skip vague opinions, marketing language and unfalsifiable statements.

Work in whatever language each source used; do not drop a claim because the
source was not in English. Write the claim text itself in English, but record
the original source language.

Limit to the {max_claims} most significant claims. Prioritise funding,
founding facts, milestones, and any regulatory or controversy item — a
regulatory or controversy claim must never be dropped in favour of an award.

Research:
{research}

Return JSON array:
[{{"claim": "<precise claim text, one fact per claim>",
   "category": "funding|career|milestone|award|regulatory|controversy|other",
   "self_reported": true,
   "source_language": "en"}}]
"""


def run(research_text: str) -> List[Claim]:
    log.info("Extracting claims", extra={"stage": STAGE})
    logging_setup.event(STAGE, "start", research_chars=len(research_text))

    data, _ = call_llm_json(
        PROMPT.format(max_claims=config.MAX_CLAIMS, research=research_text),
        search=False,
        stage=STAGE,
    )
    if not isinstance(data, list):
        raise RuntimeError("Stage 3 expected a JSON array.")

    claims: List[Claim] = []
    for item in data[: config.MAX_CLAIMS]:
        if not isinstance(item, dict):
            continue
        text = str(item.get("claim") or "").strip()
        if not text:
            continue
        superlatives = detect_superlatives(text)
        claims.append(
            Claim(
                claim=text,
                category=str(item.get("category") or "other").lower(),
                self_reported=bool(item.get("self_reported", False)),
                source_language=str(item.get("source_language") or "unknown").lower(),
                contains_superlative=bool(superlatives),
                superlative_terms=superlatives,
            )
        )

    if not claims:
        raise RuntimeError("Stage 3 extracted zero usable claims.")

    flagged = sum(1 for c in claims if c.contains_superlative)
    log.info(
        "Extracted %d claims (%d contain superlatives).", len(claims), flagged,
        extra={"stage": STAGE},
    )
    logging_setup.event(
        STAGE, "done", count=len(claims), superlatives=flagged,
        claims=[c.to_dict() for c in claims],
    )
    return claims