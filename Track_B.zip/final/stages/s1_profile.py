"""Stage 1 — Input & subject profiling.

Establishes jurisdiction, industry and likely source languages before any
research runs. This is what keeps the rest of the pipeline generic instead of
hardcoded to one person or one country.
"""

import logging
from typing import Optional

import config
import logging_setup
from llm_client import call_llm_json
from models import SubjectProfile

log = logging.getLogger("repdiag")
STAGE = "stage1_profile"

PROMPT = """You are profiling a subject before a reputation-diagnostic research run.

Subject name: {name}
LinkedIn URL (may be empty): {linkedin}

Use live web search to establish basic context ONLY. Do not yet gather claims,
funding history or achievements.

Determine:
1. Country and specific regulatory jurisdiction (for the UAE, distinguish DIFC,
   ADGM, mainland/SCA, Central Bank, DFSA, etc. — say which applies and why).
2. Industry / sector.
3. Primary company they are associated with.
4. Which public regulators, registries or court databases would be relevant for
   this jurisdiction.
5. Which language(s) local press about this subject is likely to publish in.

If the subject is ambiguous (multiple people share the name), say so in
profiling_notes and describe which one you profiled and on what basis.
If you cannot establish a field, use "unknown" — do not guess.

Return JSON:
{{"country": "", "jurisdiction": "", "industry": "", "company": "",
  "regulators": [""], "likely_languages": ["en"],
  "profiling_confidence": "high|medium|low", "profiling_notes": ""}}
"""


def run(name: str, linkedin: Optional[str]) -> SubjectProfile:
    log.info("Profiling subject: %s", name, extra={"stage": STAGE})
    logging_setup.event(STAGE, "start", subject=name, linkedin=linkedin)

    data, urls = call_llm_json(
        PROMPT.format(name=name, linkedin=linkedin or ""),
        search=True,
        max_searches=4,
        stage=STAGE,
    )
    if not isinstance(data, dict):
        raise RuntimeError("Stage 1 expected a JSON object.")

    languages = data.get("likely_languages") or ["en"]
    profile = SubjectProfile(
        name=name,
        linkedin_url=linkedin,
        country=str(data.get("country") or "unknown"),
        jurisdiction=str(data.get("jurisdiction") or "unknown"),
        industry=str(data.get("industry") or "unknown"),
        company=str(data.get("company") or "unknown"),
        regulators=[str(r) for r in (data.get("regulators") or [])],
        likely_languages=[str(l).lower() for l in languages],
        profiling_notes=str(data.get("profiling_notes") or ""),
        profiling_confidence=str(data.get("profiling_confidence") or "low"),
    )

    log.info(
        "Jurisdiction=%s | industry=%s | company=%s | languages=%s | confidence=%s",
        profile.jurisdiction, profile.industry, profile.company,
        ",".join(profile.likely_languages), profile.profiling_confidence,
        extra={"stage": STAGE},
    )
    logging_setup.event(STAGE, "done", profile=profile.to_dict(), retrieved=urls)
    return profile