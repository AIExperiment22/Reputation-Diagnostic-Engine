"""Stage 4 — Verification / cross-check.

Each claim gets VERIFY_PASSES independent search passes with deliberately
different framings; the second pass is adversarial so the model is not just
re-confirming its own first answer. The final label is computed in rules.py,
not chosen by the model.
"""

import logging
from typing import List

import config
import logging_setup
from llm_client import call_llm_json
from models import Claim, VerificationPass, VerifiedClaim
from rules import decide_status, normalize_sources

log = logging.getLogger("repdiag")
STAGE = "stage4_verify"

_FRAMINGS = [
    "Search for direct, independent confirmation of this claim.",
    "Now actively try to DISCONFIRM this claim. Search for evidence that it is "
    "false, exaggerated, mis-dated, or that the detail differs from what is "
    "stated. Report honestly whether you found any contradiction.",
    "Search once more using different query wording and different source types "
    "than an obvious first attempt — including the subject's local-language "
    "press and any public regulator or registry record for this jurisdiction.",
]

PROMPT = """Verify this factual claim against live public sources.

Claim: "{claim}"
Subject: {subject}
Jurisdiction: {jurisdiction}
Local source languages to also try: {languages}

This is verification pass {pass_number} of {total_passes}.
{framing}

Source hierarchy (strongest first):
  tier 1 — regulators, courts, government bodies, official registries
  tier 2 — established independent press
  tier 3 — the subject's own company statements, press releases, LinkedIn
  tier 4 — social media posts

Rules for your report:
- List EVERY source you actually found, with name, URL, publication date,
  language and which tier type it is.
- For each source set supports_claim to true only if it genuinely supports the
  specific claim as worded — not merely the general topic.
- Set access to "gated" for anything behind a login or paywall.
- If sources disagree, report the conflict. Use conflict="core" if they
  contradict the central fact; conflict="minor" if they agree on substance but
  differ on a detail such as an exact date or figure; otherwise "none".
- Do not invent sources or URLs. If you found nothing, return an empty sources
  array and say so. An honest empty result is the correct answer when there is
  no evidence.
- status_opinion is advisory only; the final verification label is computed by
  the deterministic rules in rules.py from the evidence returned here.
- Treat compound claims as separate material assertions. For each material
  assertion, state whether the available sources support it, contradict it, or
  leave it unresolved. Do not mark an assertion supported merely because a
  source discusses the same person, company, event, or topic.

Return JSON:
{{"status_opinion": "VERIFIED|PARTIALLY VERIFIED|UNVERIFIED",
  "conflict": "none|minor|core",
  "reasoning": "<specific reasoning citing what you actually found>",
  "components": [{{"assertion": "<one material factual assertion from the claim>",
                  "assessment": "supported|unsupported|contradicted|unclear",
                  "reason": "<specific evidence or why the evidence is insufficient>"}}],
  "sources": [{{"name": "", "url": "", "date": "", "language": "en",
               "source_type": "regulator|government|court|press|company|social",
               "supports_claim": true, "access": "public", "note": ""}}]}}
"""


def _one_pass(claim: Claim, profile, pass_number: int) -> VerificationPass:
    framing = _FRAMINGS[(pass_number - 1) % len(_FRAMINGS)]
    try:
        data, urls = call_llm_json(
            PROMPT.format(
                claim=claim.claim,
                subject=profile.name,
                jurisdiction=profile.jurisdiction,
                languages=", ".join(profile.likely_languages) or "en",
                pass_number=pass_number,
                total_passes=config.VERIFY_PASSES,
                framing=framing,
            ),
            search=True,
            max_searches=config.MAX_SEARCHES_VERIFY,
            stage=STAGE,
        )
        if not isinstance(data, dict):
            raise RuntimeError("verification pass did not return an object")

        verification = VerificationPass(
            pass_number=pass_number,
            model_status=str(data.get("status_opinion") or "UNVERIFIED").upper(),
            conflict=str(data.get("conflict") or "none").lower(),
            reasoning=str(data.get("reasoning") or "").strip(),
            sources=normalize_sources(data.get("sources")),
            retrieved_urls=urls,
        )

        # Component-level evidence is used by rules.py to prevent a compound
        # claim from becoming VERIFIED merely because the overall claim has
        # several supporting sources. This is deliberately attached at runtime
        # so the existing models and persisted schema remain unchanged.
        components = data.get("components")
        if isinstance(components, list):
            verification.components = [
                item for item in components
                if isinstance(item, dict)
            ]
        else:
            verification.components = []

        return verification

    except Exception as e:
        # A failed pass is a system error, never a factual finding (design doc §6).
        log.error(
            "Verification pass %d failed: %s", pass_number, e, extra={"stage": STAGE}
        )
        logging_setup.event(
            STAGE, "pass_failed", claim=claim.claim, pass_number=pass_number, error=str(e)
        )
        return VerificationPass(pass_number=pass_number, error=str(e))


def run(claims: List[Claim], profile) -> List[VerifiedClaim]:
    log.info(
        "Verifying %d claims × %d passes each.", len(claims), config.VERIFY_PASSES,
        extra={"stage": STAGE},
    )
    logging_setup.event(STAGE, "start", claims=len(claims), passes=config.VERIFY_PASSES)

    results: List[VerifiedClaim] = []

    for index, claim in enumerate(claims, start=1):
        log.info(
            "[%d/%d] %s", index, len(claims), claim.claim[:90], extra={"stage": STAGE}
        )
        passes = [
            _one_pass(claim, profile, 1) for n in range(1, config.VERIFY_PASSES + 1)
        ]

        errors = [p.error for p in passes if p.error]
        usable = [p for p in passes if not p.error]

        if not usable:
            verified = VerifiedClaim(
                claim=claim,
                status=config.STATUS_UNVERIFIED,
                reasoning=(
                    "Not assessed: every verification pass failed for technical "
                    "reasons. This is a system error, not a finding about the claim."
                ),
                passes=passes,
                system_error="; ".join(errors),
                rule_notes=["All verification passes failed — treat as unassessed."],
            )
            results.append(verified)
            continue

        status, sources, independent, best_tier, conflict, bilingual, notes = (
            decide_status(claim, usable)
        )

        reasoning = " ".join(p.reasoning for p in usable if p.reasoning).strip()
        if errors:
            notes.append(
                f"{len(errors)} of {len(passes)} passes failed technically; label is "
                "based on the passes that completed."
            )

        verified = VerifiedClaim(
            claim=claim,
            status=status,
            reasoning=reasoning,
            passes=passes,
            sources=sources,
            independent_source_count=independent,
            best_tier=best_tier,
            conflict=conflict,
            bilingual_review_required=bilingual,
            rule_notes=notes,
            system_error="; ".join(errors) if errors else None,
        )
        results.append(verified)

        log.info(
            "    -> %s (%d independent, best tier %d%s)",
            status, independent, best_tier,
            ", bilingual review" if bilingual else "",
            extra={"stage": STAGE},
        )
        logging_setup.event(
            STAGE, "claim_done", claim=claim.claim, status=status,
            independent=independent, best_tier=best_tier,
            conflict=conflict, bilingual=bilingual, notes=notes,
        )

    logging_setup.event(STAGE, "done", count=len(results))
    return results