"""Stage 5 — Gap analysis.

Written against patterns (self-reported vs independently reported, consistent vs
inconsistent, present vs absent), never against facts specific to one person.
"""

import json
import logging
from typing import List

import config
import logging_setup
from llm_client import call_llm_json
from models import Gap, VerifiedClaim

log = logging.getLogger("repdiag")
STAGE = "stage5_gaps"

PROMPT = """Analyse gaps in this subject's public presence, using only the
verification data below.

Subject: {subject}

Verification data:
{data}

Identify exactly 3 specific, evidenced gaps or weaknesses. Look for these
patterns rather than for anything specific to this individual:
- a fact independently reported but absent from the subject's own materials
- over-reliance on self-reported sources for load-bearing claims
- detail inconsistent across sources
- a negative, regulatory or contested finding that is unaddressed publicly
- an absence of recent independent coverage
- a superlative or headline claim the evidence does not support

If the run surfaced a genuinely negative or contested finding, you must state it
plainly as one of the three. Do not soften it and do not substitute a neutral
presentational gap in its place.

Every gap must point to specific claims or source patterns in the data above.
Do not speculate beyond the data.

Return JSON array of exactly 3:
[{{"title": "<short title>", "explanation": "<1-2 sentences>",
   "basis": "<which claims/statuses/sources in the data support this>"}}]
"""


def run(subject: str, verified: List[VerifiedClaim]) -> List[Gap]:
    log.info("Analysing gaps", extra={"stage": STAGE})
    logging_setup.event(STAGE, "start", claims=len(verified))

    payload = [
        {
            "claim": v.claim.claim,
            "category": v.claim.category,
            "status": v.status,
            "self_reported": v.claim.self_reported,
            "independent_source_count": v.independent_source_count,
            "best_tier": v.best_tier,
            "conflict": v.conflict,
            "contains_superlative": v.claim.contains_superlative,
            "rule_notes": v.rule_notes,
            "sources": [
                {"name": s.name, "type": s.source_type, "tier": s.tier,
                 "date": s.date, "language": s.language}
                for s in v.sources
            ],
        }
        for v in verified
    ]

    data, _ = call_llm_json(
        PROMPT.format(
            subject=subject, data=json.dumps(payload, indent=2, ensure_ascii=False)
        ),
        search=False,
        stage=STAGE,
    )
    if not isinstance(data, list):
        raise RuntimeError("Stage 5 expected a JSON array.")

    gaps = [
        Gap(
            title=str(item.get("title") or "Untitled gap").strip(),
            explanation=str(item.get("explanation") or "").strip(),
            basis=str(item.get("basis") or "").strip(),
        )
        for item in data[:3]
        if isinstance(item, dict)
    ]

    if len(gaps) < 3:
        raise RuntimeError(f"Stage 5 returned {len(gaps)} gaps; exactly 3 required.")

    log.info("3 gaps identified.", extra={"stage": STAGE})
    logging_setup.event(STAGE, "done", gaps=[g.to_dict() for g in gaps])
    return gaps