"""Orchestration. Each stage is checkpointed to disk as it completes, so a
failure is traceable to a stage rather than losing the whole run.

iter_run() is the streaming form used by the GUI; run() is the blocking form
used by the CLI. Both share one code path so they cannot drift apart.
"""

import logging
import traceback
from datetime import datetime
from pathlib import Path
from typing import Iterator, Optional

import config
import logging_setup
import storage
from models import RunResult
from rules import select_refusal
from stages import s1_profile, s2_research, s3_extract, s4_verify, s5_gaps, s6_report

log = logging.getLogger("repdiag")

STAGE_LABELS = [
    ("stage1_profile", "Subject profiling"),
    ("stage2_research", "Public research"),
    ("stage3_extract", "Claim extraction"),
    ("stage4_verify", "Verification passes"),
    ("stage5_gaps", "Gap analysis"),
    ("stage5_refusal", "Mandatory refusal"),
    ("stage6_report", "Report generation"),
]


class PipelineError(RuntimeError):
    def __init__(self, stage: str, original: Exception):
        super().__init__(f"Stage '{stage}' failed: {original}")
        self.stage = stage
        self.original = original


def _record_failure(result: RunResult, stage: str, error: Exception) -> None:
    entry = {
        "stage": stage,
        "error": str(error),
        "type": type(error).__name__,
        "traceback": traceback.format_exc(),
    }
    result.stage_errors.append(entry)
    logging_setup.event(stage, "stage_failed", **entry)
    log.error("Stage %s failed: %s", stage, error, extra={"stage": stage})


def iter_run(
    subject_name: str, linkedin_url: Optional[str] = None, verbose: bool = True
) -> Iterator[dict]:
    """Yield progress events as the run proceeds.

    Event shape: {"stage", "label", "state", "detail", "run_dir", "result"}
    state is one of: running, done, failed, complete.
    """
    run_dir = storage.new_run_dir(subject_name)
    logging_setup.setup(run_dir, verbose=verbose)

    result = RunResult(
        run_id=storage.run_id(run_dir),
        started_at=datetime.now().isoformat(timespec="seconds"),
    )

    log.info("Run %s started for subject: %s", result.run_id, subject_name,
             extra={"stage": "pipeline"})
    logging_setup.event(
        "pipeline", "run_start", subject=subject_name, linkedin=linkedin_url,
        model=config.MODEL, verify_passes=config.VERIFY_PASSES,
    )

    def ev(stage, state, detail="", payload=None):
        label = dict(STAGE_LABELS).get(stage, stage)
        return {
            "stage": stage, "label": label, "state": state, "detail": detail,
            "run_dir": run_dir, "result": result, "payload": payload,
        }

    try:
        # --- Stage 1 ---------------------------------------------------
        yield ev("stage1_profile", "running")
        try:
            result.profile = s1_profile.run(subject_name, linkedin_url)
            storage.save_json(run_dir, "raw/stage1_profile.json", result.profile.to_dict())
        except Exception as e:
            _record_failure(result, "stage1_profile", e)
            yield ev("stage1_profile", "failed", str(e))
            raise PipelineError("stage1_profile", e) from e
        yield ev(
            "stage1_profile", "done",
            f"{result.profile.jurisdiction} / {result.profile.industry} / "
            f"confidence {result.profile.profiling_confidence}",
        )

        # --- Stage 2 ---------------------------------------------------
        yield ev("stage2_research", "running")
        try:
            (
                result.research_text,
                result.research_sources,
                result.inaccessible_sources,
                research_meta,
            ) = s2_research.run(result.profile)
            storage.save_text(run_dir, "raw/stage2_research.txt", result.research_text)
            storage.save_json(
                run_dir, "raw/stage2_sources.json",
                {
                    "sources": [s.to_dict() for s in result.research_sources],
                    "inaccessible": [s.to_dict() for s in result.inaccessible_sources],
                    "meta": research_meta,
                },
            )
        except Exception as e:
            _record_failure(result, "stage2_research", e)
            yield ev("stage2_research", "failed", str(e))
            raise PipelineError("stage2_research", e) from e
        yield ev(
            "stage2_research", "done",
            f"{len(result.research_sources)} public sources, "
            f"{len(result.inaccessible_sources)} inaccessible",
        )

        # --- Stage 3 ---------------------------------------------------
        yield ev("stage3_extract", "running")
        try:
            result.claims = s3_extract.run(result.research_text)
            storage.save_json(run_dir, "raw/stage3_claims.json",
                              [c.to_dict() for c in result.claims])
        except Exception as e:
            _record_failure(result, "stage3_extract", e)
            yield ev("stage3_extract", "failed", str(e))
            raise PipelineError("stage3_extract", e) from e
        superlatives = sum(1 for c in result.claims if c.contains_superlative)
        yield ev("stage3_extract", "done",
                 f"{len(result.claims)} claims, {superlatives} with superlatives")

        # --- Stage 4 ---------------------------------------------------
        yield ev("stage4_verify", "running",
                 f"{len(result.claims)} claims x {config.VERIFY_PASSES} passes")
        try:
            result.verified = s4_verify.run(result.claims, result.profile)
            storage.save_json(run_dir, "raw/stage4_verified.json",
                              [v.to_dict() for v in result.verified])
        except Exception as e:
            _record_failure(result, "stage4_verify", e)
            yield ev("stage4_verify", "failed", str(e))
            raise PipelineError("stage4_verify", e) from e
        counts = {
            s: sum(1 for v in result.verified if v.status == s)
            for s in (config.STATUS_VERIFIED, config.STATUS_PARTIAL, config.STATUS_UNVERIFIED)
        }
        yield ev(
            "stage4_verify", "done",
            f"{counts[config.STATUS_VERIFIED]} verified, "
            f"{counts[config.STATUS_PARTIAL]} partial, "
            f"{counts[config.STATUS_UNVERIFIED]} unverified",
        )

        # --- Stage 5a --------------------------------------------------
        yield ev("stage5_gaps", "running")
        try:
            result.gaps = s5_gaps.run(subject_name, result.verified)
            storage.save_json(run_dir, "raw/stage5_gaps.json",
                              [g.to_dict() for g in result.gaps])
        except Exception as e:
            _record_failure(result, "stage5_gaps", e)
            yield ev("stage5_gaps", "failed", str(e))
            raise PipelineError("stage5_gaps", e) from e
        yield ev("stage5_gaps", "done", "3 gaps identified")

        # --- Stage 5b: refusal is code logic, not model judgement ------
        yield ev("stage5_refusal", "running")
        result.refused, result.refusal_reason = select_refusal(result.verified)
        logging_setup.event(
            "stage5_refusal", "selected",
            claim=result.refused.claim.claim if result.refused else None,
            reason=result.refusal_reason,
        )
        yield ev(
            "stage5_refusal", "done",
            result.refused.claim.claim[:70] if result.refused else "no claims available",
        )

        # --- Stage 6 ---------------------------------------------------
        yield ev("stage6_report", "running")
        result.finished_at = datetime.now().isoformat(timespec="seconds")
        report_text = s6_report.run(result, run_dir)
        storage.save_json(run_dir, "pipeline_data.json", result.to_dict())
        yield ev("stage6_report", "done", "report written")

        log.info("Run complete. Artefacts in %s", run_dir.resolve(),
                 extra={"stage": "pipeline"})
        logging_setup.event("pipeline", "run_complete", run_dir=str(run_dir))
        yield ev("pipeline", "complete", str(run_dir), payload=report_text)

    except PipelineError:
        result.finished_at = datetime.now().isoformat(timespec="seconds")
        storage.save_json(run_dir, "pipeline_data.partial.json", result.to_dict())
        log.error("Run aborted. Partial state saved to %s/pipeline_data.partial.json",
                  run_dir, extra={"stage": "pipeline"})
        raise
    finally:
        logging_setup.close()


def run(subject_name: str, linkedin_url: Optional[str] = None,
        verbose: bool = True) -> Path:
    """Blocking form used by the CLI."""
    run_dir = None
    report_text = ""
    for event in iter_run(subject_name, linkedin_url, verbose=verbose):
        run_dir = event["run_dir"]
        if event["state"] == "complete":
            report_text = event["payload"] or ""
    if report_text:
        print("\n" + report_text + "\n")
    return run_dir