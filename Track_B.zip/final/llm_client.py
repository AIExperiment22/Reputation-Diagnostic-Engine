"""Claude transport. Keeps the prototype's public surface — call_llm / call_llm_json —
so stage code is independent of how requests are actually sent.

Swap the body of _send() if you use a different authorized transport; nothing
else in the system needs to change.
"""

import json
import logging
import time
from typing import Any, List, Tuple

import anthropic

import config
import logging_setup

log = logging.getLogger("repdiag")

_client: anthropic.Anthropic | None = None

WEB_SEARCH_TOOL = {"type": "web_search_20250305", "name": "web_search"}

_RETRYABLE = (
    anthropic.RateLimitError,
    anthropic.APIConnectionError,
    anthropic.InternalServerError,
    anthropic.APITimeoutError,
)


def get_client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        config.require_api_key()
        _client = anthropic.Anthropic(api_key=config.API_KEY, timeout=600.0)
    return _client


def _extract_text(message: Any) -> str:
    parts = []
    for block in message.content:
        if getattr(block, "type", None) == "text":
            parts.append(block.text)
    return "\n".join(parts).strip()


def _extract_search_urls(message: Any) -> List[str]:
    """URLs actually retrieved by the server-side search tool, for audit."""
    urls: List[str] = []
    for block in message.content:
        if getattr(block, "type", None) != "web_search_tool_result":
            continue
        content = getattr(block, "content", None) or []
        if isinstance(content, list):
            for item in content:
                url = getattr(item, "url", None)
                if url and url not in urls:
                    urls.append(url)
    return urls


def _send(prompt: str, search: bool, max_searches: int) -> Tuple[str, List[str]]:
    kwargs: dict = {
        "model": config.MODEL,
        "max_tokens": config.MAX_TOKENS,
        "messages": [{"role": "user", "content": prompt}],
    }
    if search:
        tool = dict(WEB_SEARCH_TOOL)
        tool["max_uses"] = max_searches
        kwargs["tools"] = [tool]

    message = get_client().messages.create(**kwargs)
    return _extract_text(message), _extract_search_urls(message)


def call_llm(
    prompt: str,
    retries: int = config.LLM_RETRIES,
    retry_delay: int = config.LLM_RETRY_DELAY,
    search: bool = False,
    max_searches: int = config.MAX_SEARCHES_VERIFY,
    stage: str = "llm",
) -> Tuple[str, List[str]]:
    """Send a text request. Returns (text, retrieved_urls). Retries transient failures."""
    last_error: Exception | None = None

    for attempt in range(1, retries + 1):
        try:
            text, urls = _send(prompt, search, max_searches)
            if not text:
                raise RuntimeError("Claude returned an empty response.")
            logging_setup.event(
                stage, "llm_ok", attempt=attempt, chars=len(text), urls=len(urls)
            )
            return text, urls

        except _RETRYABLE as e:
            last_error = e
            wait = retry_delay * attempt
            log.warning(
                "Transient API failure (%s). Attempt %d/%d, retrying in %ds.",
                type(e).__name__, attempt, retries, wait,
                extra={"stage": stage},
            )
            logging_setup.event(
                stage, "llm_retry", attempt=attempt, error=str(e), wait_s=wait
            )
            if attempt < retries:
                time.sleep(wait)

        except anthropic.APIStatusError as e:
            logging_setup.event(stage, "llm_fatal", error=str(e), status=e.status_code)
            raise RuntimeError(f"Claude API error {e.status_code}: {e}") from e

        except RuntimeError as e:
            last_error = e
            wait = retry_delay * attempt
            logging_setup.event(stage, "llm_retry", attempt=attempt, error=str(e))
            if attempt < retries:
                log.warning(
                    "%s Retrying in %ds.", e, wait, extra={"stage": stage}
                )
                time.sleep(wait)

    raise RuntimeError(f"Claude request failed after {retries} attempts: {last_error}")


_JSON_INSTRUCTIONS = """

IMPORTANT OUTPUT FORMAT REQUIREMENTS:
Return ONLY valid JSON.
Do not use Markdown. Do not use code fences. Do not add explanations before or after.
The first character of your response must be { or [.
The last character of your response must be } or ].
"""


def _strip_fences(result: str) -> str:
    result = result.strip()
    if result.startswith("```json"):
        result = result[len("```json"):].strip()
    elif result.startswith("```"):
        result = result[len("```"):].strip()
    if result.endswith("```"):
        result = result[:-3].strip()
    return result


def _recover_json(result: str) -> Any:
    """Parse JSON, tolerating stray text around the payload."""
    result = _strip_fences(result)
    try:
        return json.loads(result)
    except json.JSONDecodeError:
        pass

    first_object, first_array = result.find("{"), result.find("[")
    positions = [p for p in (first_object, first_array) if p != -1]
    if not positions:
        raise RuntimeError("Claude did not return valid JSON (no object/array found).")

    start = min(positions)
    end = max(result.rfind("}"), result.rfind("]"))
    if end == -1 or end <= start:
        raise RuntimeError("Claude did not return valid JSON (unterminated payload).")

    try:
        return json.loads(result[start:end + 1])
    except json.JSONDecodeError as e:
        raise RuntimeError(f"Claude returned invalid JSON: {e}") from e


def call_llm_json(
    prompt: str,
    retries: int = config.LLM_RETRIES,
    retry_delay: int = config.LLM_RETRY_DELAY,
    search: bool = False,
    max_searches: int = config.MAX_SEARCHES_VERIFY,
    stage: str = "llm",
) -> Tuple[Any, List[str]]:
    """Send a request and return (parsed_json, retrieved_urls).

    A JSON parse failure is retried as a fresh request, because a malformed
    response is usually a one-off formatting slip rather than a stable failure.
    """
    last_error: Exception | None = None

    for attempt in range(1, retries + 1):
        text, urls = call_llm(
            prompt + _JSON_INSTRUCTIONS,
            retries=retries,
            retry_delay=retry_delay,
            search=search,
            max_searches=max_searches,
            stage=stage,
        )
        try:
            return _recover_json(text), urls
        except RuntimeError as e:
            last_error = e
            log.warning(
                "Invalid JSON on attempt %d/%d: %s", attempt, retries, e,
                extra={"stage": stage},
            )
            logging_setup.event(
                stage, "json_parse_failed", attempt=attempt,
                error=str(e), raw_preview=text[:800],
            )
            if attempt < retries:
                time.sleep(retry_delay)

    raise RuntimeError(f"Could not obtain valid JSON from Claude: {last_error}")