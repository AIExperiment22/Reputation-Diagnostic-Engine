"""Run persistence. Each run gets its own directory; raw stage artifacts are
written as they are produced, so a crash mid-run still leaves an audit trail."""

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

import config


def slugify(text: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return slug[:48] or "subject"


def new_run_dir(subject_name: str) -> Path:
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    path = Path(config.RUNS_DIR) / f"{stamp}_{slugify(subject_name)}"
    (path / "raw").mkdir(parents=True, exist_ok=True)
    return path


def save_text(run_dir: Path, name: str, content: str) -> Path:
    path = run_dir / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def save_json(run_dir: Path, name: str, payload: Any) -> Path:
    path = run_dir / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, default=str), encoding="utf-8"
    )
    return path


def run_id(run_dir: Path) -> str:
    return run_dir.name