"""Standalone one-page diagnostic renderer.

Usage:
    python generate_one_pager.py runs/20260918-140322_mark-chahwan

Reads that run's pipeline_data.json and writes diagnostic_onepager.docx
alongside it. Independent of s6_report.py so you can regenerate the
one-pager without rerunning the pipeline.
"""

import json
import sys
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor

import house_style

MAX_CLAIMS_ON_PAGE = 3
REASONING_CHARS = 80
PRIORITY_CATEGORIES = ("regulatory", "controversy", "funding")


def prioritize(verified: list, limit: int) -> tuple[list, int]:
    def rank(v):
        score = 0
        if v["claim"]["category"] in PRIORITY_CATEGORIES:
            score -= 3
        if v["status"] == "UNVERIFIED":
            score -= 2
        if v["conflict"] != "none":
            score -= 2
        if v["claim"]["contains_superlative"]:
            score -= 1
        return score

    ordered = sorted(verified, key=rank)
    return ordered[:limit], max(0, len(ordered) - limit)


def source_line(v: dict) -> str:
    supporting = [s for s in v["sources"] if s["supports_claim"]]
    if not supporting:
        return "No supporting public source found."
    return "; ".join(f"{s['name']} ({s['date']})" for s in supporting[:2])


def set_margins(doc: Document, inches: float = 0.35) -> None:
    for section in doc.sections:
        section.top_margin = Inches(inches)
        section.bottom_margin = Inches(inches)
        section.left_margin = Inches(inches)
        section.right_margin = Inches(inches)


def build(run_dir: Path) -> Path:
    data_path = run_dir / "pipeline_data.json"
    if not data_path.exists():
        data_path = run_dir / "pipeline_data.partial.json"
    if not data_path.exists():
        raise FileNotFoundError(f"No pipeline data found in {run_dir}")

    data = json.loads(data_path.read_text(encoding="utf-8"))
    profile = data.get("profile") or {}
    verified = data.get("verified", [])
    gaps = data.get("gaps", [])
    refused = data.get("refused")
    refusal_reason = data.get("refusal_reason", "")

    doc = Document()
    set_margins(doc)
    base = doc.styles["Normal"]
    base.font.name = "Calibri"
    base.font.size = Pt(10)

    title = doc.add_paragraph()
    title.paragraph_format.space_after = Pt(1)
    run = title.add_run("REPUTATION DIAGNOSTIC")
    run.bold = True
    run.font.size = Pt(14)

    meta = doc.add_paragraph()
    meta.paragraph_format.space_after = Pt(1)
    meta.add_run(
        f"Subject: {profile.get('name', 'unknown')}   "
        f"Company: {profile.get('company', 'unknown')}   "
        f"Jurisdiction: {profile.get('jurisdiction', 'unknown')}\n"
        f"Run: {data.get('run_id', run_dir.name)}   "
        f"Generated: {data.get('finished_at', '')}"
    ).font.size = Pt(10)

    sign = doc.add_paragraph()
    sign.paragraph_format.space_after = Pt(2)
    sign_run = sign.add_run(
        "Reviewed by: ______________________   Date: __________   "
        "(not client-ready without sign-off)"
    )
    sign_run.bold = True
    sign_run.font.size = Pt(10)
    sign_run.font.color.rgb = RGBColor(0xB0, 0x00, 0x00)

    h1 = doc.add_paragraph()
    h1.paragraph_format.space_before = Pt(1)
    h1.paragraph_format.space_after = Pt(1)
    h1.add_run("1. FACT VERIFICATION").bold = True

    shown, held_back_count = prioritize(verified, MAX_CLAIMS_ON_PAGE)

    table = doc.add_table(rows=1, cols=4)
    table.style = "Table Grid"
    table.autofit = True
    widths = [Inches(0.7), Inches(3.4), Inches(2.0), Inches(1.4)]
    headers = ["Status", "Claim", "Basis", "Source"]
    for i, header in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = header
        cell.paragraphs[0].runs[0].bold = True
        cell.paragraphs[0].runs[0].font.size = Pt(10)
        cell.width = widths[i]

    for v in shown:
        row = table.add_row().cells
        status_text = v["status"]
        if v["conflict"] != "none":
            status_text += f"\n[{v['conflict'].upper()} CONFLICT]"
        if v["bilingual_review_required"]:
            status_text += "\n[BILINGUAL]"
        if v["claim"]["contains_superlative"]:
            status_text += "\n[SUPERLATIVE]"

        reasoning = house_style.apply(v.get("reasoning") or "None recorded.")[:REASONING_CHARS]

        values = [status_text, v["claim"]["claim"], reasoning, source_line(v)]
        for i, val in enumerate(values):
            row[i].text = val
            for p in row[i].paragraphs:
                p.paragraph_format.space_before = Pt(0)
                p.paragraph_format.space_after = Pt(0)
                for r in p.runs:
                    r.font.size = Pt(10)
            row[i].width = widths[i]

    if held_back_count:
        note = doc.add_paragraph()
        note.paragraph_format.space_before = Pt(1)
        note.paragraph_format.space_after = Pt(0)
        note.add_run(
            f"+ {held_back_count} additional claim(s) assessed. Full detail: "
            "reviewer console / pipeline_data.json."
        ).font.size = Pt(10)

    h2 = doc.add_paragraph()
    h2.paragraph_format.space_before = Pt(2)
    h2.paragraph_format.space_after = Pt(1)
    h2.add_run("2. GAPS").bold = True
    for i, gap in enumerate(gaps, start=1):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        r1 = p.add_run(f"{i}. {gap['title']}: ")
        r1.bold = True
        r1.font.size = Pt(10)
        r2 = p.add_run(house_style.apply(gap["explanation"]))
        r2.font.size = Pt(10)

    h3 = doc.add_paragraph()
    h3.paragraph_format.space_before = Pt(2)
    h3.paragraph_format.space_after = Pt(1)
    h3.add_run("3. CLAIM REFUSED").bold = True
    refusal_p = doc.add_paragraph()
    refusal_p.paragraph_format.space_before = Pt(0)
    refusal_p.paragraph_format.space_after = Pt(0)
    if refused:
        refusal_p.add_run(f"{refused['claim']['claim']} [{refused['status']}]. ").bold = True
    refusal_p.add_run(house_style.apply(refusal_reason)).font.size = Pt(10)
    for r in refusal_p.runs:
        r.font.size = Pt(10)

    lim = data.get("limitations") or {}
    h4 = doc.add_paragraph()
    h4.paragraph_format.space_before = Pt(2)
    h4.paragraph_format.space_after = Pt(1)
    h4.add_run("4. LIMITATIONS").bold = True
    lim_p = doc.add_paragraph()
    lim_p.paragraph_format.space_before = Pt(0)
    lim_p.paragraph_format.space_after = Pt(0)
    lim_p.add_run(
        f"{lim.get('verification_depth', 'unknown depth')}. "
        f"{lim.get('claims_assessed', 0)} claims assessed "
        f"({lim.get('verified_count', 0)} verified / {lim.get('partial_count', 0)} partial / "
        f"{lim.get('unverified_count', 0)} unverified). "
        f"{lim.get('public_sources_checked', 0)} public sources checked. "
        f"{lim.get('claims_resting_on_non_english_sources', 0)} claim(s) rest on non-English "
        f"sources. This system assists a human reviewer; it does not replace one."
    ).font.size = Pt(10)

    out_path = run_dir / "diagnostic_onepager.docx"
    doc.save(out_path)
    return out_path


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python generate_one_pager.py <run_dir>")
        raise SystemExit(1)
    result_path = build(Path(sys.argv[1]))
    print(f"Written: {result_path.resolve()}")