import os
from dotenv import load_dotenv

load_dotenv()


def _int(name: str, default: int) -> int:
    raw = os.getenv(name, "").strip()
    try:
        return int(raw) if raw else default
    except ValueError:
        return default


API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5").strip() or "claude-sonnet-5"

# Verification depth — disclosed in every report.
VERIFY_PASSES = max(2, min(3, _int("VERIFY_PASSES", 3)))

MAX_CLAIMS = _int("MAX_CLAIMS", 10)
MAX_SEARCHES_RESEARCH = _int("MAX_SEARCHES_RESEARCH", 8)
MAX_SEARCHES_VERIFY = _int("MAX_SEARCHES_VERIFY", 4)

LLM_RETRIES = _int("LLM_RETRIES", 4)
LLM_RETRY_DELAY = _int("LLM_RETRY_DELAY", 20)
MAX_TOKENS = _int("MAX_TOKENS", 8000)

RUNS_DIR = os.getenv("RUNS_DIR", "runs").strip() or "runs"

# Source hierarchy. Lower tier number = stronger evidence.
TIER_BY_TYPE = {
    "regulator": 1,
    "government": 1,
    "court": 1,
    "press": 2,
    "company": 3,
    "self": 3,
    "social": 4,
    "unknown": 4,
}
INDEPENDENT_TIERS = {1, 2}
STRONGEST_TIERS = {1, 2}

STATUS_VERIFIED = "VERIFIED"
STATUS_PARTIAL = "PARTIALLY VERIFIED"
STATUS_UNVERIFIED = "UNVERIFIED"
STATUS_ORDER = [STATUS_UNVERIFIED, STATUS_PARTIAL, STATUS_VERIFIED]


def require_api_key() -> None:
    if not API_KEY:
        raise RuntimeError(
            "ANTHROPIC_API_KEY is not set. Copy .env.example to .env and fill it in."
        )