"""Growpido house rules applied to client-facing output.

Scope: the rendered report only. Internal logs, JSON and code comments are not
client-facing and are left alone.
Rules enforced: no em dashes, no en dashes used as punctuation, no hashtags,
no AI filler vocabulary.
"""

import re

_FILLER = [
    (r"\bdelve into\b", "examine"),
    (r"\bdelves into\b", "examines"),
    (r"\bin the realm of\b", "in"),
    (r"\bit is worth noting that\b", ""),
    (r"\bit's worth noting that\b", ""),
    (r"\bleverage(d|s)?\b", lambda m: {"": "use", "d": "used", "s": "uses"}[m.group(1) or ""]),
    (r"\bseamless(ly)?\b", "direct"),
    (r"\brobust\b", "reliable"),
    (r"\bcutting[- ]edge\b", "current"),
    (r"\bgame[- ]chang(er|ing)\b", "significant"),
    (r"\btestament to\b", "evidence of"),
    (r"\bnavigat(e|ing) the\b", "handle the"),
    (r"\bunlock(ing)? the\b", "open the"),
]


def apply(text: str) -> str:
    """Normalise a client-facing string to Growpido house style."""
    if not text:
        return text

    # Em dash and en dash used as sentence punctuation become a comma or colon.
    text = re.sub(r"\s*[\u2014\u2013]\s*", ", ", text)
    # Repair the ", ," artefacts that substitution can create.
    text = re.sub(r",\s*,", ",", text)
    text = re.sub(r",\s*([.;:!?])", r"\1", text)
    # Hashtags.
    text = re.sub(r"(?<!\w)#(\w+)", r"\1", text)

    for pattern, replacement in _FILLER:
        text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)

    text = re.sub(r"[ \t]{2,}(?=\S)", " ", text)
    return text.strip()


def check(text: str) -> list:
    """Return remaining house-rule violations, for display to the reviewer."""
    problems = []
    if "\u2014" in text:
        problems.append("Em dash present in output.")
    if re.search(r"(?<!\w)#\w+", text):
        problems.append("Hashtag present in output.")
    for pattern, _ in _FILLER:
        if re.search(pattern, text, flags=re.IGNORECASE):
            problems.append(f"Filler vocabulary matched: {pattern}")
    return problems