"""Deterministic fact-integrity rules (design doc §5).

Status is decided here in code, never by the model. The model supplies evidence;
these functions decide what that evidence is worth. This is what makes the
verification rules identical across subjects and languages.
"""

import re
from typing import Dict, List, Tuple
from urllib.parse import urlparse

import config
from models import Claim, Source, VerificationPass

SUPERLATIVE_PATTERN = re.compile(
    r"\b("
    r"first|1st|inaugural|largest|biggest|smallest|only|sole|best|top|leading|"
    r"fastest|highest|lowest|most|record|unprecedented|pioneer|pioneering|"
    r"youngest|oldest|premier|number one|no\.?\s?1"
    r")\b",
    re.IGNORECASE,
)

_REGULATOR_HINTS = (
    ".gov", "difc", "adgm", "sca.gov", "centralbank", "adgm.com", "dfsa",
    "fca.org.uk", "sec.gov", "court", "tribunal", "registry",
)
_SOCIAL_HINTS = (
    "linkedin.com", "twitter.com", "x.com", "facebook.com", "instagram.com",
    "tiktok.com", "medium.com", "reddit.com", "youtube.com",
)


def detect_superlatives(text: str) -> List[str]:
    return sorted({m.group(0).lower() for m in SUPERLATIVE_PATTERN.finditer(text)})


def domain_of(url: str) -> str:
    try:
        host = urlparse(url).netloc.lower()
    except ValueError:
        return ""
    return host[4:] if host.startswith("www.") else host


def classify_tier(source: Source) -> int:
    """Tier from declared type, corrected by domain when the domain is decisive."""
    declared = (source.source_type or "unknown").strip().lower()
    tier = config.TIER_BY_TYPE.get(declared, 4)

    domain = domain_of(source.url)
    if domain:
        if any(h in domain for h in _REGULATOR_HINTS):
            tier = min(tier, 1)
        elif any(h in domain for h in _SOCIAL_HINTS):
            tier = max(tier, 4)
    return tier


def normalize_sources(raw: List[dict]) -> List[Source]:
    out: List[Source] = []
    for item in raw or []:
        if not isinstance(item, dict):
            continue
        source = Source(
            name=str(item.get("name") or item.get("outlet") or "unknown").strip(),
            url=str(item.get("url") or "").strip(),
            date=str(item.get("date") or "unknown").strip(),
            language=str(item.get("language") or "unknown").strip().lower(),
            source_type=str(item.get("source_type") or item.get("type") or "unknown")
            .strip()
            .lower(),
            supports_claim=bool(item.get("supports_claim", True)),
            access=str(item.get("access") or "public").strip().lower(),
            note=str(item.get("note") or "").strip(),
        )
        source.tier = classify_tier(source)
        out.append(source)
    return out


def merge_sources(passes: List[VerificationPass]) -> List[Source]:
    """Union across passes, deduplicated by URL (or name+date when URL is absent)."""
    seen: Dict[str, Source] = {}
    for p in passes:
        for s in p.sources:
            key = domain_of(s.url) + "|" + (urlparse(s.url).path if s.url else "")
            if not s.url:
                key = f"{s.name.lower()}|{s.date}"
            existing = seen.get(key)
            if existing is None or (s.supports_claim and not existing.supports_claim):
                seen[key] = s
    return list(seen.values())


def _independent_domains(sources: List[Source]) -> List[Source]:
    """Supporting tier-1/2 sources, one per distinct domain — two articles on the
    same outlet are one source, not two."""
    by_domain: Dict[str, Source] = {}
    for s in sources:
        if not s.supports_claim or s.tier not in config.INDEPENDENT_TIERS:
            continue
        if s.access != "public":
            continue
        key = domain_of(s.url) or s.name.lower()
        current = by_domain.get(key)
        if current is None or s.tier < current.tier:
            by_domain[key] = s
    return list(by_domain.values())


def _downgrade(status: str) -> str:
    idx = config.STATUS_ORDER.index(status)
    return config.STATUS_ORDER[max(0, idx - 1)]


def _worst_conflict(passes: List[VerificationPass]) -> str:
    rank = {"none": 0, "minor": 1, "core": 2}
    worst = "none"
    for p in passes:
        if rank.get(p.conflict, 0) > rank.get(worst, 0):
            worst = p.conflict
    return worst


def _component_assessments(passes: List[VerificationPass]) -> List[dict]:
    """Return material-assertion assessments supplied by Stage 4.

    Stage 4 adds these at runtime without changing the existing persisted model.
    Missing component assessments are allowed so older runs and conservative
    single-assertion claims keep the original evidence rules.
    """
    assessments: List[dict] = []
    for p in passes:
        for item in getattr(p, "components", []) or []:
            if not isinstance(item, dict):
                continue
            assertion = str(item.get("assertion") or "").strip()
            assessment = str(item.get("assessment") or "").strip().lower()
            if assertion and assessment in {"supported", "unsupported", "contradicted", "unclear"}:
                assessments.append({
                    "assertion": assertion,
                    "assessment": assessment,
                    "reason": str(item.get("reason") or "").strip(),
                })
    return assessments


def decide_status(
    claim: Claim, passes: List[VerificationPass]
) -> Tuple[str, List[Source], int, int, str, bool, List[str]]:
    """Return (status, merged_sources, independent_count, best_tier, conflict,
    bilingual_flag, rule_notes)."""
    notes: List[str] = []
    sources = merge_sources(passes)
    conflict = _worst_conflict(passes)

    supporting = [s for s in sources if s.supports_claim and s.access == "public"]
    independent = _independent_domains(sources)
    best_tier = min((s.tier for s in supporting), default=4)
    components = _component_assessments(passes)

    # Base rule: two independent credible sources = VERIFIED.
    if len(independent) >= 2:
        status = config.STATUS_VERIFIED
    elif len(independent) == 1 or supporting:
        status = config.STATUS_PARTIAL
        notes.append(
            "Single independent source or self-reported only — capped at Partially Verified."
        )
    else:
        status = config.STATUS_UNVERIFIED
        notes.append("No supporting public source found within the defined search depth.")

    # A compound claim is only Verified when every material assertion is supported.
    # One unresolved material assertion caps the whole claim at Partially Verified;
    # a contradicted material assertion makes the core claim Unverified.
    if components and status != config.STATUS_UNVERIFIED:
        contradicted = [c for c in components if c["assessment"] == "contradicted"]
        unresolved = [
            c for c in components
            if c["assessment"] in {"unsupported", "unclear"}
        ]
        if contradicted:
            status = config.STATUS_UNVERIFIED
            notes.append(
                "A material assertion in this compound claim is contradicted by the "
                "verification evidence: " + contradicted[0]["assertion"]
            )
        elif unresolved:
            if status == config.STATUS_VERIFIED:
                status = config.STATUS_PARTIAL
            notes.append(
                "A material assertion in this compound claim remains unsupported or "
                "unresolved: " + unresolved[0]["assertion"]
            )

    # Tier-4-only can never be VERIFIED.
    if supporting and all(s.tier == 4 for s in supporting):
        if status == config.STATUS_VERIFIED:
            status = config.STATUS_PARTIAL
        notes.append("Evidence rests only on tier-4 (social) sources — cannot be Verified.")

    # Conflicts.
    if conflict == "core":
        status = config.STATUS_UNVERIFIED
        notes.append("Sources directly conflict on the core fact.")
    elif conflict == "minor":
        notes.append(
            "Sources agree on the core claim but differ on a minor, non-core detail; "
            "the minor variation does not by itself downgrade otherwise sufficient evidence."
        )

    # Superlatives demand the strongest tier.
    if claim.contains_superlative:
        strong = [s for s in independent if s.tier in config.STRONGEST_TIERS]
        if len(strong) < 2 and status != config.STATUS_UNVERIFIED:
            status = _downgrade(status)
            notes.append(
                "Superlative claim ("
                + ", ".join(claim.superlative_terms)
                + ") without two strongest-tier sources — downgraded."
            )

        # A self-reported superlative cannot be promoted to Verified merely
        # because independent press repeats the same company-originated claim.
        if claim.self_reported and status == config.STATUS_VERIFIED:
            status = config.STATUS_PARTIAL
            notes.append(
                "Superlative claim is marked self-reported; repeated secondary coverage "
                "does not by itself establish the comparative claim independently."
            )

    # Bilingual review: flag when non-English evidence is load-bearing.
    non_english = [
        s for s in independent if s.language not in ("en", "english", "unknown", "")
    ]
    bilingual = False
    if non_english:
        english_only = [s for s in independent if s not in non_english]
        if len(english_only) < 2:
            bilingual = True
            notes.append(
                "Verification depends on non-English source(s) ("
                + ", ".join(sorted({s.language for s in non_english}))
                + ") — bilingual reviewer sign-off required."
            )

    return status, sources, len(independent), best_tier, conflict, bilingual, notes


def select_refusal(verified: List) -> Tuple[object, str]:
    """Mandatory refusal (design doc §5): at least one claim is excluded from the
    verified set in every report, chosen by rule rather than model preference."""
    if not verified:
        return None, "No claims were extracted, so no claim could be published."

    unverified = [v for v in verified if v.status == config.STATUS_UNVERIFIED]
    if unverified:
        pick = max(unverified, key=lambda v: len(v.sources))
        return pick, (
            "Excluded from the publishable set: no independent public source confirmed "
            "this claim within the disclosed search depth. " + (pick.reasoning or "")
        ).strip()

    superlative_partials = [
        v for v in verified
        if v.status == config.STATUS_PARTIAL and v.claim.contains_superlative
    ]
    if superlative_partials:
        pick = superlative_partials[0]
        return pick, (
            "Excluded from the publishable set: superlative claim not supported by two "
            "strongest-tier independent sources. " + (pick.reasoning or "")
        ).strip()

    partials = [v for v in verified if v.status == config.STATUS_PARTIAL]
    if partials:
        pick = partials[0]
        return pick, (
            "Excluded from the publishable set: evidence caps this claim at Partially "
            "Verified. " + (pick.reasoning or "")
        ).strip()

    pick = min(verified, key=lambda v: (v.independent_source_count, -v.best_tier))
    return pick, (
        "Excluded from the publishable set: weakest evidence base in this run "
        f"({pick.independent_source_count} independent source(s), best tier {pick.best_tier}). "
        "Every report withholds at least one claim by design."
    )