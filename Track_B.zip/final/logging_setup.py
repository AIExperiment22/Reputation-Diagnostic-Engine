"""Structured per-run logging. Every stage event lands in run.log (human) and
events.jsonl (machine). Nothing is swallowed — design doc §6, 'no silent failures'."""

import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

_JSONL_HANDLE = None


class _ConsoleFormat(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        stage = getattr(record, "stage", "-")
        return f"[{record.levelname:<7}] [{stage}] {record.getMessage()}"


def setup(run_dir: Path, verbose: bool = True) -> logging.Logger:
    global _JSONL_HANDLE

    run_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("repdiag")
    logger.handlers.clear()
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    console = logging.StreamHandler(sys.stdout)
    console.setLevel(logging.DEBUG if verbose else logging.INFO)
    console.setFormatter(_ConsoleFormat())
    logger.addHandler(console)

    fileh = logging.FileHandler(run_dir / "run.log", encoding="utf-8")
    fileh.setLevel(logging.DEBUG)
    fileh.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)-8s %(message)s")
    )
    logger.addHandler(fileh)

    if _JSONL_HANDLE:
        _JSONL_HANDLE.close()
    _JSONL_HANDLE = open(run_dir / "events.jsonl", "a", encoding="utf-8")
    return logger


def event(stage: str, kind: str, **fields) -> None:
    """Append one structured event. Safe to call before setup (becomes a no-op)."""
    if not _JSONL_HANDLE:
        return
    record = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "stage": stage,
        "kind": kind,
    }
    record.update(fields)
    _JSONL_HANDLE.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
    _JSONL_HANDLE.flush()


def close() -> None:
    global _JSONL_HANDLE
    if _JSONL_HANDLE:
        _JSONL_HANDLE.close()
        _JSONL_HANDLE = None