"""Reputation Diagnostic Engine, operator interface.

Run:  streamlit run app.py

This is the reviewer's console. The key difference from the CLI is the approval
gate: a report stays in DRAFT state, watermarked and undownloadable in final
form, until a named reviewer confirms each verified claim and signs off. That
approval is written to disk and logged, so who approved what is auditable.
"""

import json
import os
from datetime import datetime
from pathlib import Path

import streamlit as st

import config
import house_style
import pipeline
import storage

st.set_page_config(
    page_title="Reputation Diagnostic Engine",
    page_icon="RD",
    layout="wide",
)

STATUS_COLOR = {
    config.STATUS_VERIFIED: "#1a7f37",
    config.STATUS_PARTIAL: "#9a6700",
    config.STATUS_UNVERIFIED: "#b00000",
}


# ======================================================================
# Run discovery and loading
# ======================================================================

def list_runs():
    root = Path(config.RUNS_DIR)
    if not root.exists():
        return []
    runs = [p for p in root.iterdir() if p.is_dir()]
    return sorted(runs, key=lambda p: p.name, reverse=True)


def load_run(run_dir: Path) -> dict:
    for name in ("pipeline_data.json", "pipeline_data.partial.json"):
        path = run_dir / name
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            data["_partial"] = name.endswith("partial.json")
            return data
    return {}


def load_events(run_dir: Path) -> list:
    path = run_dir / "events.jsonl"
    if not path.exists():
        return []
    events = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return events


def approval_path(run_dir: Path) -> Path:
    return run_dir / "APPROVAL.json"


def load_approval(run_dir: Path) -> dict:
    path = approval_path(run_dir)
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


def write_approval(run_dir: Path, reviewer: str, notes: str, claim_decisions: dict) -> dict:
    """Record sign-off and emit the approved report. This is the human gate."""
    record = {
        "reviewer": reviewer.strip(),
        "approved_at": datetime.now().isoformat(timespec="seconds"),
        "reviewer_notes": notes.strip(),
        "claim_decisions": claim_decisions,
        "run_id": run_dir.name,
    }
    approval_path(run_dir).write_text(
        json.dumps(record, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    draft = run_dir / "diagnostic_report.txt"
    if draft.exists():
        text = draft.read_text(encoding="utf-8")
        text = text.replace(
            "Reviewed by   : ______________________  Date: __________",
            f"Reviewed by   : {record['reviewer']}  Date: {record['approved_at'][:10]}",
        ).replace(
            "                [MANDATORY, not client-ready until a named reviewer signs off]",
            "                [APPROVED FOR CLIENT USE]",
        ).replace(
            "                [MANDATORY — not client-ready until a named reviewer signs off]",
            "                [APPROVED FOR CLIENT USE]",
        )
        held = [c for c, d in claim_decisions.items() if d != "Approve"]
        if held:
            text += "\n\nREVIEWER HELD CLAIMS (excluded from client use)\n"
            text += "-" * 78 + "\n"
            for claim in held:
                text += f"  [{claim_decisions[claim]}] {claim}\n"
        if record["reviewer_notes"]:
            text += f"\nREVIEWER NOTES\n{'-' * 78}\n{record['reviewer_notes']}\n"
        (run_dir / "diagnostic_report.APPROVED.txt").write_text(text, encoding="utf-8")

    return record


# ======================================================================
# Sidebar: configuration
# ======================================================================

with st.sidebar:
    st.header("Configuration")

    key_present = bool(config.API_KEY or os.getenv("ANTHROPIC_API_KEY"))
    if key_present:
        st.success("ANTHROPIC_API_KEY loaded")
    else:
        st.error("ANTHROPIC_API_KEY missing. Set it in .env before running.")

    model = st.text_input("Model", value=config.MODEL)
    passes = st.radio(
        "Verification passes per claim", options=[2, 3],
        index=1 if config.VERIFY_PASSES == 3 else 0, horizontal=True,
        help="Pass 1 seeks confirmation, pass 2 actively seeks disconfirmation, "
             "pass 3 varies query wording and source types.",
    )
    max_claims = st.slider("Max claims to assess", 3, 15, config.MAX_CLAIMS)
    research_searches = st.slider("Research searches", 3, 15, config.MAX_SEARCHES_RESEARCH)
    verify_searches = st.slider("Searches per verification pass", 2, 8,
                                config.MAX_SEARCHES_VERIFY)

    config.MODEL = model.strip() or config.MODEL
    config.VERIFY_PASSES = passes
    config.MAX_CLAIMS = max_claims
    config.MAX_SEARCHES_RESEARCH = research_searches
    config.MAX_SEARCHES_VERIFY = verify_searches

    st.divider()
    st.caption(
        "Public sources only. No login-gated data, no outreach. "
        "No output is client-ready without reviewer sign-off."
    )


# ======================================================================
# Header and run controls
# ======================================================================

st.title("Reputation Diagnostic Engine")
st.caption(
    "Research, verify, and diagnose a public founder or fund manager from public "
    "sources. Every label is computed by rule, not chosen by the model."
)

tab_run, tab_report, tab_claims, tab_sources, tab_logs, tab_history = st.tabs(
    ["Run", "Report and sign-off", "Claims", "Sources", "Logs", "Run history"]
)

if "active_run" not in st.session_state:
    st.session_state.active_run = None

with tab_run:
    col_a, col_b = st.columns([2, 3])
    with col_a:
        subject_name = st.text_input("Subject name", placeholder="Mark Chahwan")
    with col_b:
        linkedin_url = st.text_input(
            "LinkedIn URL (optional)",
            placeholder="https://www.linkedin.com/in/...",
            help="Used only to disambiguate which person is being researched. "
                 "The profile itself is login-gated and is never scraped.",
        )

    start = st.button("Run diagnostic", type="primary", disabled=not key_present)

    if start:
        if not subject_name.strip():
            st.error("Enter a subject name.")
        else:
            progress = st.progress(0.0)
            slots = {}
            total = len(pipeline.STAGE_LABELS)
            container = st.container()
            for key, label in pipeline.STAGE_LABELS:
                slots[key] = container.empty()
                slots[key].markdown(f"- {label}: waiting")

            done_count = 0
            try:
                for event in pipeline.iter_run(
                    subject_name.strip(), linkedin_url.strip() or None, verbose=False
                ):
                    stage, state = event["stage"], event["state"]
                    st.session_state.active_run = str(event["run_dir"])

                    if stage in slots:
                        label = event["label"]
                        if state == "running":
                            slots[stage].markdown(f"- **{label}: running**")
                        elif state == "done":
                            done_count += 1
                            detail = f" ({event['detail']})" if event["detail"] else ""
                            slots[stage].markdown(f"- {label}: done{detail}")
                            progress.progress(min(1.0, done_count / total))
                        elif state == "failed":
                            slots[stage].markdown(f"- {label}: FAILED, {event['detail']}")

                    if state == "complete":
                        progress.progress(1.0)
                        st.success(f"Run complete. Artefacts in {event['detail']}")

            except pipeline.PipelineError as e:
                st.error(f"Run aborted at {e.stage}: {e.original}")
                st.info(
                    "Partial state was saved to pipeline_data.partial.json and the full "
                    "traceback is in run.log. Nothing was silently discarded."
                )
            except Exception as e:
                st.error(f"Unexpected failure: {e}")

    if st.session_state.active_run:
        st.info(f"Active run: {st.session_state.active_run}")


# ======================================================================
# Run selection for the read-only tabs
# ======================================================================

runs = list_runs()
selected_dir = None

if runs:
    default_index = 0
    if st.session_state.active_run:
        names = [p.name for p in runs]
        active_name = Path(st.session_state.active_run).name
        if active_name in names:
            default_index = names.index(active_name)

    with st.sidebar:
        st.divider()
        st.subheader("Viewing run")
        choice = st.selectbox(
            "Run", options=[p.name for p in runs], index=default_index,
            label_visibility="collapsed",
        )
        selected_dir = Path(config.RUNS_DIR) / choice

data = load_run(selected_dir) if selected_dir else {}


# ======================================================================
# Report and sign-off
# ======================================================================

with tab_report:
    if not data:
        st.info("No run selected. Start a run on the Run tab.")
    else:
        approval = load_approval(selected_dir)
        draft = selected_dir / "diagnostic_report.txt"
        approved = selected_dir / "diagnostic_report.APPROVED.txt"

        if approval:
            st.success(
                f"Approved by {approval['reviewer']} on {approval['approved_at']}"
            )
        elif data.get("_partial"):
            st.error("This run did not complete. No report was generated.")
        else:
            st.warning(
                "DRAFT. Not client-ready. Review every claim below and sign off "
                "before this leaves the building."
            )

        if draft.exists():
            text = draft.read_text(encoding="utf-8")
            problems = house_style.check(text)
            if problems:
                st.error("House-style violations: " + "; ".join(problems))
            st.code(text, language=None)

        st.divider()
        st.subheader("Reviewer sign-off")

        if approval:
            st.write("Decisions recorded:")
            st.json(approval.get("claim_decisions", {}))
            if approved.exists():
                st.download_button(
                    "Download approved report (.txt)",
                    approved.read_bytes(),
                    file_name=f"{selected_dir.name}_diagnostic_APPROVED.txt",
                )
        else:
            verified_claims = data.get("verified", [])
            if not verified_claims:
                st.info("No claims to review.")
            else:
                st.caption(
                    "Each claim must be actively approved. Anything held is excluded "
                    "from the approved report and listed in it by name."
                )
                decisions = {}
                for i, item in enumerate(verified_claims):
                    claim_text = item["claim"]["claim"]
                    status = item["status"]
                    color = STATUS_COLOR.get(status, "#555")
                    flags = []
                    if item.get("bilingual_review_required"):
                        flags.append("bilingual review")
                    if item["claim"].get("contains_superlative"):
                        flags.append("superlative")
                    if item.get("system_error"):
                        flags.append("technical failure in a pass")
                    flag_text = f" [{', '.join(flags)}]" if flags else ""

                    st.markdown(
                        f"<span style='color:{color};font-weight:600'>{status}</span>"
                        f"{flag_text}<br>{claim_text}",
                        unsafe_allow_html=True,
                    )
                    default = 0 if status == config.STATUS_VERIFIED else 1
                    decisions[claim_text] = st.radio(
                        "Decision", ["Approve", "Hold", "Reject"],
                        index=default, horizontal=True,
                        key=f"decision_{selected_dir.name}_{i}",
                        label_visibility="collapsed",
                    )
                    st.caption(item.get("reasoning", "")[:400] or "No reasoning recorded.")
                    st.divider()

                reviewer = st.text_input("Reviewer name (required)")
                notes = st.text_area("Reviewer notes (optional)")
                confirm = st.checkbox(
                    "I have checked every approved claim against its named source."
                )

                if st.button("Sign off and release", type="primary"):
                    if not reviewer.strip():
                        st.error("A named reviewer is required. Initials are not a name.")
                    elif not confirm:
                        st.error("Confirm you checked the sources before signing off.")
                    else:
                        record = write_approval(
                            selected_dir, reviewer, notes, decisions
                        )
                        st.success(f"Approved by {record['reviewer']}.")
                        st.rerun()

        st.divider()
        docx = selected_dir / "diagnostic_report.docx"
        cols = st.columns(3)
        if draft.exists():
            cols[0].download_button(
                "Draft report (.txt)", draft.read_bytes(),
                file_name=f"{selected_dir.name}_diagnostic_DRAFT.txt",
            )
        if docx.exists():
            cols[1].download_button(
                "Draft report (.docx)", docx.read_bytes(),
                file_name=f"{selected_dir.name}_diagnostic_DRAFT.docx",
            )
        full = selected_dir / "pipeline_data.json"
        if full.exists():
            cols[2].download_button(
                "Full run data (.json)", full.read_bytes(),
                file_name=f"{selected_dir.name}_pipeline_data.json",
            )


# ======================================================================
# Claims
# ======================================================================

with tab_claims:
    if not data or not data.get("verified"):
        st.info("No verified claims for this run.")
    else:
        verified = data["verified"]
        counts = {
            s: sum(1 for v in verified if v["status"] == s)
            for s in (config.STATUS_VERIFIED, config.STATUS_PARTIAL, config.STATUS_UNVERIFIED)
        }
        metric_cols = st.columns(4)
        metric_cols[0].metric("Verified", counts[config.STATUS_VERIFIED])
        metric_cols[1].metric("Partially verified", counts[config.STATUS_PARTIAL])
        metric_cols[2].metric("Unverified", counts[config.STATUS_UNVERIFIED])
        metric_cols[3].metric(
            "Bilingual review", sum(1 for v in verified if v.get("bilingual_review_required"))
        )

        chosen = st.multiselect(
            "Filter by status",
            [config.STATUS_VERIFIED, config.STATUS_PARTIAL, config.STATUS_UNVERIFIED],
            default=[config.STATUS_VERIFIED, config.STATUS_PARTIAL, config.STATUS_UNVERIFIED],
        )

        table = [
            {
                "Status": v["status"],
                "Category": v["claim"]["category"],
                "Claim": v["claim"]["claim"],
                "Independent sources": v["independent_source_count"],
                "Best tier": v["best_tier"],
                "Conflict": v["conflict"],
                "Superlative": "yes" if v["claim"]["contains_superlative"] else "",
                "Bilingual": "yes" if v["bilingual_review_required"] else "",
            }
            for v in verified
            if v["status"] in chosen
        ]
        st.dataframe(table, use_container_width=True, hide_index=True)

        st.subheader("Verification detail")
        for v in verified:
            if v["status"] not in chosen:
                continue
            with st.expander(f"[{v['status']}] {v['claim']['claim'][:90]}"):
                st.write("**Rules applied**")
                for note in v["rule_notes"] or ["No rule adjustments."]:
                    st.write(f"- {note}")
                if v.get("system_error"):
                    st.error(f"Technical failure: {v['system_error']}")
                st.write("**Reasoning**")
                st.write(v.get("reasoning") or "None recorded.")
                st.write("**Passes**")
                for p in v["passes"]:
                    if p.get("error"):
                        st.write(f"Pass {p['pass_number']}: FAILED, {p['error']}")
                    else:
                        st.write(
                            f"Pass {p['pass_number']}: model opinion "
                            f"{p['model_status']}, conflict {p['conflict']}, "
                            f"{len(p['sources'])} sources"
                        )
                # st.write("**Sources**")
                # st.dataframe(
                #     [
                #         {
                #             "Name": s["name"], "Tier": s["tier"], "Type": s["source_type"],
                #             "Date": s["date"], "Lang": s["language"],
                #             "Supports": "yes" if s["supports_claim"] else "no",
                #             "Access": s["access"], "URL": s["url"],
                #         }
                #         for s in v["sources"]
                #     ] or [{"Name": "none found"}],
                #     use_container_width=True, hide_index=True,
                # )

                st.write("**Sources**")
                st.dataframe(
                    [
                        {
                            "Name": s["name"], "Tier": s["tier"], "Type": s["source_type"],
                            "Date": s["date"], "Lang": s["language"],
                            "Supports": "yes" if s["supports_claim"] else "no",
                            "Access": s["access"], "URL": s["url"],
                        }
                        for s in v["sources"]
                    ] or [{"Name": "none found"}],
                    use_container_width=True, hide_index=True,
                    column_config={
                        "URL": st.column_config.LinkColumn(
                            "URL",
                            display_text="Open source ↗",
                        )
                    },
                )

        st.divider()
        st.subheader("Gaps")
        for i, gap in enumerate(data.get("gaps", []), start=1):
            st.markdown(f"**{i}. {gap['title']}**")
            st.write(gap["explanation"])
            if gap.get("basis"):
                st.caption(f"Basis: {gap['basis']}")

        st.subheader("Mandatory refusal")
        refused = data.get("refused")
        if refused:
            st.error(f"{refused['claim']['claim']}  [{refused['status']}]")
        st.write(data.get("refusal_reason", ""))


# ======================================================================
# Sources
# ======================================================================

with tab_sources:
    if not data:
        st.info("No run selected.")
    else:
        st.subheader("Public sources collected")
        st.dataframe(
            [
                {
                    "Name": s["name"], "Tier": s["tier"], "Type": s["source_type"],
                    "Date": s["date"], "Lang": s["language"], "URL": s["url"],
                }
                for s in data.get("research_sources", [])
            ] or [{"Name": "none"}],
            use_container_width=True, hide_index=True,
        )

        st.subheader("Inaccessible sources")
        inaccessible = data.get("inaccessible_sources", [])
        if inaccessible:
            st.dataframe(
                [
                    {"Name": s["name"], "Access": s["access"],
                     "Reason": s["note"], "URL": s["url"]}
                    for s in inaccessible
                ],
                use_container_width=True, hide_index=True,
            )
        else:
            st.write("None encountered in this run.")

        st.subheader("Subject profile")
        st.json(data.get("profile") or {})

        st.subheader("Raw research text")
        st.text_area(
            "Stage 2 output", data.get("research_text", ""), height=300,
            label_visibility="collapsed",
        )


# ======================================================================
# Logs
# ======================================================================

with tab_logs:
    if not selected_dir:
        st.info("No run selected.")
    else:
        events = load_events(selected_dir)
        errors = [
            e for e in events
            if e["kind"] in ("stage_failed", "pass_failed", "llm_retry",
                             "json_parse_failed", "docx_failed", "house_style_warning")
        ]
        st.metric("Logged events", len(events))
        if errors:
            st.warning(f"{len(errors)} failure or retry events. Nothing was swallowed.")
            st.dataframe(
                [
                    {"Time": e["ts"], "Stage": e["stage"], "Kind": e["kind"],
                     "Error": str(e.get("error", ""))[:160]}
                    for e in errors
                ],
                use_container_width=True, hide_index=True,
            )
        else:
            st.success("No failures or retries in this run.")

        if data.get("stage_errors"):
            st.subheader("Stage aborts")
            for entry in data["stage_errors"]:
                with st.expander(f"{entry['stage']}: {entry['type']}"):
                    st.code(entry["traceback"])

        st.subheader("Full event stream")
        st.dataframe(
            [{"Time": e["ts"], "Stage": e["stage"], "Kind": e["kind"]} for e in events]
            or [{"Time": "none"}],
            use_container_width=True, hide_index=True,
        )

        log_file = selected_dir / "run.log"
        if log_file.exists():
            st.download_button(
                "Download run.log", log_file.read_bytes(),
                file_name=f"{selected_dir.name}_run.log",
            )


# ======================================================================
# Run history
# ======================================================================

with tab_history:
    if not runs:
        st.info("No runs yet.")
    else:
        rows = []
        for path in runs:
            run_data = load_run(path)
            approval = load_approval(path)
            verified = run_data.get("verified", [])
            rows.append(
                {
                    "Run": path.name,
                    "Subject": (run_data.get("profile") or {}).get("name", "unknown"),
                    "Claims": len(verified),
                    "Verified": sum(1 for v in verified if v["status"] == config.STATUS_VERIFIED),
                    "State": (
                        "incomplete" if run_data.get("_partial")
                        else "approved" if approval else "draft"
                    ),
                    "Reviewer": approval.get("reviewer", ""),
                }
            )
        st.dataframe(rows, use_container_width=True, hide_index=True)